"""EXTERNAL: evaluate a trained open-source nanoGPT checkpoint with the SAME fixed validation windows, the SAME needle-in-Wikipedia
test and the SAME prompts as the tree model (nanoGPT has a learned position table of block_size entries, so longer prompts than
block_size cannot be fed; they are skipped).
  python external/nanogpt_eval.py --repo treeattn_repo --nanogpt nanoGPT --ckpt nanoGPT/out-wiki/ckpt.pt --data_dir data/wiki --out runs/demo_nanogpt.txt"""
import argparse
import json
import os
import sys

import numpy as np
import torch

p = argparse.ArgumentParser()
p.add_argument('--repo', default='treeattn_repo')
p.add_argument('--nanogpt', default='nanoGPT')
p.add_argument('--ckpt', required=True)
p.add_argument('--data_dir', default='data/wiki')
p.add_argument('--eval_lens', default='1024')
p.add_argument('--lengths', default='512,1024')
p.add_argument('--depths', default='0.1,0.3,0.5,0.7,0.9')
p.add_argument('--min_answer_id', type=int, default=3000, help='answer words are whole-word tokens with id >= this (rarer words)')
p.add_argument('--n', type=int, default=20)
p.add_argument('--val_windows', type=int, default=24)
p.add_argument('--gen', type=int, default=40)
p.add_argument('--out', default='')
a = p.parse_args()
sys.path.insert(0, a.repo)
sys.path.insert(0, a.nanogpt)
from model import GPT, GPTConfig                                  # nanoGPT's own model.py
from tokenizers import Tokenizer
from treeattn.lmdata import bucket_line, val_windows, window
from treeattn.needles import FREE_PROMPTS, answer_ids_from_vocab, needle_demo, run_needle_eval

dev = 'cuda' if torch.cuda.is_available() else 'cpu'
ck = torch.load(a.ckpt, map_location=dev, weights_only=False)
model = GPT(GPTConfig(**ck['model_args']))
sd = {k[len('_orig_mod.'):] if k.startswith('_orig_mod.') else k: v for k, v in ck['model'].items()}
model.load_state_dict(sd)
model.to(dev).eval()
block = ck['model_args']['block_size']
meta = json.load(open(os.path.join(a.data_dir, 'meta.json')))
va = np.memmap(os.path.join(a.data_dir, 'val.bin'), dtype=np.uint16, mode='r')
tok = Tokenizer.from_file(os.path.join(a.data_dir, 'tokenizer.json'))
enc, dec = (lambda s: tok.encode(s).ids), (lambda ids: tok.decode(list(ids)))
answer_ids = answer_ids_from_vocab(tok.get_vocab(), min_id=a.min_answer_id)
use_amp = dev == 'cuda'
print('nanoGPT | params %.2fM | block_size %d | trained %s iters' % (sum(q.numel() for q in model.parameters()) / 1e6, block, ck.get('iter_num')))


@torch.no_grad()
def logits_fn(ids):
    x = torch.tensor([ids[-block:]], device=dev)
    with torch.autocast(dev, dtype=torch.float16, enabled=use_amp):
        lg, _ = model(x)
    return lg[0, -1].float().cpu().numpy()


@torch.no_grad()
def gen_fn(ids, n):
    x = torch.tensor([ids[-block:]], device=dev)
    return model.generate(x, n, temperature=1.0, top_k=1)[0, x.shape[1]:].tolist()      # top_k=1 = greedy


out = ['=== nanoGPT: validation loss / accuracy by position bucket (same fixed windows as every other model) ===']
for T in [int(v) for v in a.eval_lens.split(',')]:
    if T > block:
        out.append('T=%d skipped (block_size %d)' % (T, block))
        continue
    tot = hit = None
    starts = val_windows(va, meta['eot'], T, a.val_windows, cross=bool(meta.get('cross_docs', False)))
    for s in starts:
        x, y = window(va, s, T, dev)
        with torch.no_grad(), torch.autocast(dev, dtype=torch.float16, enabled=use_amp):
            lg, _ = model(x, y)                                     # with targets nanoGPT returns logits for every position
        ce = torch.nn.functional.cross_entropy(lg.float().view(-1, lg.size(-1)), y.view(-1), reduction='none')
        ok = (lg.argmax(-1).view(-1) == y.view(-1)).float()
        tot, hit = (ce, ok) if tot is None else (tot + ce, hit + ok)
    out.append('T=%-6d (%d windows) %s' % (T, len(starts), bucket_line(tot / len(starts), hit / len(starts), T, block)))
    print(out[-1], flush=True)
depths = [float(v) for v in a.depths.split(',')]
out.append('')
out.append('NEEDLE-IN-WIKIPEDIA | model: nanoGPT (dense) | %d answer words (guess rate ~%.2f%%) | cases per cell: %d' % (len(answer_ids), 100.0 / len(answer_ids), a.n))
out.append('length   ' + ' '.join('%5d%%' % int(d * 100) for d in depths) + '  | control')
for L in [int(v) for v in a.lengths.split(',')]:
    if L > block:
        out.append('%-8d skipped (block_size %d)' % (L, block))
        continue
    res, ctrl = run_needle_eval(logits_fn, va, enc, answer_ids, L, depths, a.n, seed=1)
    out.append('%-8d ' % L + ' '.join('%6.2f' % res[d] for d in depths) + '  | %.2f' % ctrl)
    print(out[-1], flush=True)
out.append('')
out.append('=== WHAT THE MODEL SAYS (greedy) ===')
out.append(needle_demo(logits_fn, gen_fn, va, enc, dec, answer_ids, L=min(1024, block), depth=0.5))
for pr in FREE_PROMPTS:
    out.append('  PROMPT: %r' % pr)
    out.append('  ANSWER: %r' % dec(gen_fn(enc(pr), a.gen)))
text = '\n'.join(out)
print('\n' + text)
if a.out:
    open(a.out, 'w').write(text)
