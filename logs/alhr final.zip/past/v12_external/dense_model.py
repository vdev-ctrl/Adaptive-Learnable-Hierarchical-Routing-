"""EXTERNAL (not part of the repo): a standard dense GPT (full causal softmax attention + RoPE). Besides the normal forward it can
extract routing labels: for every query row and layer, the key OUTSIDE the cheap local window that gets the largest share of a
head's dense attention. The tree model is later trained with those labels (it never sees any dense attention itself)."""
import math
import sys

import torch
import torch.nn as nn
import torch.nn.functional as F


class Block(nn.Module):
    def __init__(self, n_embd, n_head):
        super().__init__()
        self.n_head, self.dh = n_head, n_embd // n_head
        self.ln1, self.ln2 = nn.LayerNorm(n_embd), nn.LayerNorm(n_embd)
        self.qkv, self.proj = nn.Linear(n_embd, 3 * n_embd, bias=False), nn.Linear(n_embd, n_embd, bias=False)
        self.fc, self.out = nn.Linear(n_embd, 4 * n_embd, bias=False), nn.Linear(4 * n_embd, n_embd, bias=False)

    def forward(self, x, rotary, label_cfg=None):
        b, T, C = x.shape
        H, dh = self.n_head, self.dh
        q, k, v = [t.view(b, T, H, dh).transpose(1, 2) for t in self.qkv(self.ln1(x)).split(C, 2)]
        pos = torch.arange(T, device=x.device)
        q, k = rotary(q, pos, dh, 10000.0), rotary(k, pos, dh, 10000.0)
        lab = None
        if label_cfg is None:
            y = F.scaled_dot_product_attention(q, k, v, is_causal=True)
        else:                                                           # explicit attention, chunked over queries (training of labels only)
            t_idx = torch.arange(T, device=x.device).view(1, 1, 1, T)
            ys, confs, tgts = [], [], []
            for s0 in range(0, T, label_cfg['chunk']):
                s1 = min(T, s0 + label_cfg['chunk'])
                n = s1 - s0
                qp = torch.arange(s0, s1, device=x.device).view(1, 1, n, 1)
                sc = (q[:, :, s0:s1] @ k.transpose(-1, -2)).float() / math.sqrt(dh)
                w = torch.softmax(sc.masked_fill(t_idx > qp, float('-inf')), -1)         # (b,H,n,T)
                ys.append(w.to(v.dtype) @ v)
                far = ((qp - t_idx) >= label_cfg['min_dist']) & (t_idx != 0)             # outside the local window, not the sink
                conf, arg = w.masked_fill(~far, 0.0).permute(0, 2, 1, 3).reshape(b, n, H * T).max(-1)
                confs.append(conf)
                tgts.append(arg % T)
            y = torch.cat(ys, 2)
            lab = (torch.cat(confs, 1), torch.cat(tgts, 1))
        x = x + self.proj(y.transpose(1, 2).reshape(b, T, C))
        return x + self.out(F.gelu(self.fc(self.ln2(x)))), lab


class GPT(nn.Module):
    def __init__(self, vocab, n_layer, n_head, n_embd):
        super().__init__()
        self.n_layer = n_layer
        self.wte = nn.Embedding(vocab, n_embd)
        self.blocks = nn.ModuleList([Block(n_embd, n_head) for _ in range(n_layer)])
        self.ln_f = nn.LayerNorm(n_embd)
        self.head = nn.Linear(n_embd, vocab, bias=False)
        self.head.weight = self.wte.weight
        for m in self.modules():
            if isinstance(m, (nn.Linear, nn.Embedding)):
                nn.init.normal_(m.weight, 0.0, 0.02)
        for n, p in self.named_parameters():
            if n.endswith('proj.weight') or n.endswith('out.weight'):
                nn.init.normal_(p, 0.0, 0.02 / math.sqrt(2 * n_layer))

    def forward(self, idx, label_cfg=None):
        from treeattn.attention import rotary                       # the same RoPE function as the tree model (caller put the repo on sys.path)
        x = self.wte(idx)
        labs = []
        for blk in self.blocks:
            x, lab = blk(x, rotary, label_cfg)
            labs.append(lab)
        logits = self.head(self.ln_f(x))
        return logits if label_cfg is None else (logits, labs)
