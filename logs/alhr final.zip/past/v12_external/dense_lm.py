"""EXTERNAL dense baseline (not part of the repo): a standard GPT with full causal softmax attention + RoPE, trained on the same
PG-19 token files, with the same batches (same seed/step), schedule, sizes and validation windows as scripts/train_lm.py.
  python external/dense_lm.py --repo treeattn_repo --data_dir data/pg19 --out runs/lm_dense
Dense attention is quadratic: the 16k evaluation is the largest it is asked to do. Plain RoPE is not trained beyond --seq_len, so
losses past it show its out-of-the-box extrapolation (state this when you report it)."""
import argparse
import json
import math
import os
import sys
import time

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

p = argparse.ArgumentParser()
p.add_argument('--repo', default='treeattn_repo')
p.add_argument('--data_dir', default='data/pg19')
p.add_argument('--out', default='runs/lm_dense')
p.add_argument('--seed', type=int, default=0)
p.add_argument('--seq_len', type=int, default=1024)
p.add_argument('--eval_lens', default='1024,2048,4096,8192,16384')
p.add_argument('--val_windows', type=int, default=24)
p.add_argument('--batch', type=int, default=16)
p.add_argument('--steps', type=int, default=2500)
p.add_argument('--lr', type=float, default=1e-3)
p.add_argument('--warmup', type=int, default=100)
p.add_argument('--n_layer', type=int, default=6)
p.add_argument('--n_head', type=int, default=6)
p.add_argument('--n_embd', type=int, default=384)
p.add_argument('--log_every', type=int, default=50)
p.add_argument('--val_every', type=int, default=500)
a = p.parse_args()
sys.path.insert(0, a.repo)
from dense_model import GPT
from treeattn.lmdata import bucket_line, train_batch, val_windows, window

dev = 'cuda' if torch.cuda.is_available() else 'cpu'
meta = json.load(open(os.path.join(a.data_dir, 'meta.json')))


torch.manual_seed(a.seed)
model = GPT(meta['vocab'], a.n_layer, a.n_head, a.n_embd).to(dev)
print('dense | device %s | params %.2fM | seq_len %d | batch %d | steps %d' % (
    dev, sum(q.numel() for q in model.parameters()) / 1e6, a.seq_len, a.batch, a.steps), flush=True)
tr = np.memmap(os.path.join(a.data_dir, 'train.bin'), dtype=np.uint16, mode='r')
va = np.memmap(os.path.join(a.data_dir, 'val.bin'), dtype=np.uint16, mode='r')
opt = torch.optim.AdamW(model.parameters(), lr=a.lr, betas=(0.9, 0.95), weight_decay=0.1)
use_amp = dev == 'cuda'
scaler = torch.amp.GradScaler('cuda', enabled=use_amp)
os.makedirs(a.out, exist_ok=True)


@torch.no_grad()
def evaluate(T, n):
    model.eval()
    tot = hit = None
    cnt = 0
    for s in val_windows(va, meta['eot'], T, n, cross=bool(meta.get('cross_docs', False))):
        x, y = window(va, s, T, dev)
        with torch.autocast(dev, dtype=torch.float16, enabled=use_amp):
            lg = model(x)
        ce = F.cross_entropy(lg.float().view(-1, lg.size(-1)), y.view(-1), reduction='none')
        ok = (lg.argmax(-1).view(-1) == y.view(-1)).float()
        tot, hit = (ce, ok) if tot is None else (tot + ce, hit + ok)
        cnt += 1
    model.train()
    return tot / max(cnt, 1), hit / max(cnt, 1), cnt


t_start, ema = time.time(), None
for step in range(a.steps):
    lr = a.lr * min(1.0, (step + 1) / a.warmup) * (0.1 + 0.9 * 0.5 * (1 + math.cos(math.pi * step / a.steps)))
    for g in opt.param_groups:
        g['lr'] = lr
    x, y = train_batch(tr, a.batch, a.seq_len, step, a.seed, dev)
    with torch.autocast(dev, dtype=torch.float16, enabled=use_amp):
        lg = model(x)
    loss = F.cross_entropy(lg.float().view(-1, lg.size(-1)), y.view(-1))
    opt.zero_grad(set_to_none=True)
    scaler.scale(loss).backward()
    scaler.unscale_(opt)
    torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
    scaler.step(opt)
    scaler.update()
    ema = loss.item() if ema is None else 0.98 * ema + 0.02 * loss.item()
    if (step + 1) % a.log_every == 0 or step == 0:
        print('step %d | lm %.3f (ema %.3f) | lr %.1e | %.2fs/step' % (step + 1, loss.item(), ema, lr, (time.time() - t_start) / (step + 1)), flush=True)
    if (step + 1) % a.val_every == 0:
        ce, ac, n = evaluate(a.seq_len, 16)
        print('  VAL step %d | T=%d | loss %.3f acc %.3f (%d windows)' % (step + 1, a.seq_len, ce.mean().item(), ac.mean().item(), n), flush=True)
torch.save({'model': model.state_dict()}, os.path.join(a.out, 'ckpt.pt'))

print('\n=== FINAL validation loss by position bucket (nats/token and next-token top-1 accuracy; same fixed windows for every model). Trained at %d.' % a.seq_len)
for T in [int(v) for v in a.eval_lens.split(',')]:
    try:
        ce, ac, n = evaluate(T, a.val_windows)
        print('T=%-6d (%d windows) %s' % (T, n, bucket_line(ce, ac, T, a.seq_len)), flush=True)
    except torch.cuda.OutOfMemoryError:
        print('T=%-6d out of memory (dense attention)' % T, flush=True)
        torch.cuda.empty_cache()
