"""EXTERNAL: put our token files into the folder layout the open-source nanoGPT (github.com/karpathy/nanoGPT) expects, so it trains on
exactly the same tokens with exactly the same tokenizer: <nanogpt>/data/<name>/{train.bin,val.bin,meta.pkl}."""
import argparse
import os
import pickle
import shutil

import json

p = argparse.ArgumentParser()
p.add_argument('--data_dir', default='data/wiki')
p.add_argument('--out', default='nanoGPT/data/wiki')
a = p.parse_args()
os.makedirs(a.out, exist_ok=True)
for f in ('train.bin', 'val.bin'):
    shutil.copy(os.path.join(a.data_dir, f), os.path.join(a.out, f))
meta = json.load(open(os.path.join(a.data_dir, 'meta.json')))
pickle.dump({'vocab_size': meta['vocab']}, open(os.path.join(a.out, 'meta.pkl'), 'wb'))
print('nanoGPT dataset ready in', a.out, '| vocab', meta['vocab'])
