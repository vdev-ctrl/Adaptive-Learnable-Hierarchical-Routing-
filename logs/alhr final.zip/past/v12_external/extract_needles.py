"""EXTERNAL step 2 of the pipeline: run the TRAINED dense model once over the training windows and write routing labels for the tree
model. For every window i (tokens [i*T, i*T+T], as in scripts/train_lm.py --labels_dir) and every layer, up to --rows query rows are kept:
the rows where one key outside the local window (distance >= --min_dist, not the sink) gets more than --thresh of a head's dense
attention, strongest first. Row = (query position, key position). The tree repo only reads these files; it never computes dense attention.
  python external/extract_needles.py --repo treeattn_repo --data_dir data/wiki --dense_ckpt runs/lm_dense/ckpt.pt --out data/wiki_labels"""
import argparse
import json
import os
import sys
import time

import numpy as np
import torch

p = argparse.ArgumentParser()
p.add_argument('--repo', default='treeattn_repo')
p.add_argument('--data_dir', default='data/wiki')
p.add_argument('--dense_ckpt', required=True)
p.add_argument('--out', default='data/wiki_labels')
p.add_argument('--T', type=int, default=1024)
p.add_argument('--n_windows', type=int, default=64000)
p.add_argument('--rows', type=int, default=128)
p.add_argument('--thresh', type=float, default=0.1)
p.add_argument('--min_dist', type=int, default=8)
p.add_argument('--batch', type=int, default=8)
p.add_argument('--chunk', type=int, default=128)
p.add_argument('--n_layer', type=int, default=8)
p.add_argument('--n_head', type=int, default=6)
p.add_argument('--n_embd', type=int, default=384)
a = p.parse_args()
sys.path.insert(0, a.repo)
from dense_model import GPT
from treeattn.lmdata import PAD

dev = 'cuda' if torch.cuda.is_available() else 'cpu'
meta = json.load(open(os.path.join(a.data_dir, 'meta.json')))
tr = np.memmap(os.path.join(a.data_dir, 'train.bin'), dtype=np.uint16, mode='r')
n_win = min(a.n_windows, (len(tr) - 1) // a.T)
model = GPT(meta['vocab'], a.n_layer, a.n_head, a.n_embd).to(dev)
model.load_state_dict(torch.load(a.dense_ckpt, map_location=dev, weights_only=False)['model'])
model.eval()
os.makedirs(a.out, exist_ok=True)
shape = (n_win, a.n_layer, a.rows)
lq = np.memmap(os.path.join(a.out, 'labels_q.u16'), mode='w+', dtype=np.uint16, shape=shape)
lt = np.memmap(os.path.join(a.out, 'labels_t.u16'), mode='w+', dtype=np.uint16, shape=shape)
lq[:] = PAD
lt[:] = PAD
cfg = {'chunk': a.chunk, 'min_dist': a.min_dist}
valid_rows = np.zeros(a.n_layer)
dist_hist = np.zeros((a.n_layer, 4))                                     # label distance: <32, <256, <1024, >=1024
t0 = time.time()
with torch.no_grad(), torch.autocast(dev, dtype=torch.float16, enabled=dev == 'cuda'):
    for s in range(0, n_win, a.batch):
        idx = np.arange(s, min(s + a.batch, n_win))
        x = torch.from_numpy(np.stack([tr[i * a.T:i * a.T + a.T] for i in idx]).astype(np.int64)).to(dev)
        _, labs = model(x, label_cfg=cfg)
        for l, (conf, tgt) in enumerate(labs):
            vals, qi = conf.float().topk(min(a.rows, conf.shape[1]), dim=1)
            ti = tgt.gather(1, qi)
            ok = vals > a.thresh
            q_out = torch.where(ok, qi, torch.full_like(qi, PAD)).cpu().numpy().astype(np.uint16)
            t_out = torch.where(ok, ti, torch.full_like(ti, PAD)).cpu().numpy().astype(np.uint16)
            lq[s:s + len(idx), l, :q_out.shape[1]] = q_out
            lt[s:s + len(idx), l, :t_out.shape[1]] = t_out
            okn = ok.cpu().numpy()
            valid_rows[l] += okn.sum()
            d = (qi - ti).cpu().numpy()[okn]
            dist_hist[l] += [(d < 32).sum(), ((d >= 32) & (d < 256)).sum(), ((d >= 256) & (d < 1024)).sum(), (d >= 1024).sum()]
        if (s // a.batch) % 200 == 0:
            print('windows %d / %d | %.0fs' % (s, n_win, time.time() - t0), flush=True)
lq.flush(), lt.flush()
json.dump({'T': a.T, 'n_windows': int(n_win), 'n_layer': a.n_layer, 'rows': a.rows, 'thresh': a.thresh, 'min_dist': a.min_dist},
          open(os.path.join(a.out, 'labels_meta.json'), 'w'))
print('done | %d windows | label rows per window per layer (max %d): %s' % (
    n_win, a.rows, ' '.join('%.0f' % (valid_rows[l] / n_win) for l in range(a.n_layer))))
print('label distance mix per layer (<32, 32-255, 256-1023, >=1024 tokens back), share of labels:')
for l in range(a.n_layer):
    tot = max(dist_hist[l].sum(), 1)
    print('  layer %d: ' % l + ' '.join('%.2f' % (v / tot) for v in dist_hist[l]))
