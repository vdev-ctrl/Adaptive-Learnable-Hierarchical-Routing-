"""EXTERNAL dense control: a plain dense causal transformer, same size / rotary / task / curriculum as the tree model.
Benchmark only. Not part of the treeattn package."""
import argparse, math, os, sys, time
import torch
import torch.nn as nn
import torch.nn.functional as F
sys.path.insert(0, '/kaggle/working/treeattn_repo')
from treeattn import Config
from treeattn.attention import rotary
from treeattn.evaluate import fmt_row, needle_accuracy
from treeattn.model import MLP, LayerNorm
from treeattn.tasks import NeedleTask


class DenseAttn(nn.Module):
    def __init__(s, cfg):
        super().__init__()
        s.H, s.rot, s.base = cfg.n_head, cfg.rot_dims, cfg.rope_base
        s.qkv, s.proj = nn.Linear(cfg.n_embd, 3 * cfg.n_embd, bias=False), nn.Linear(cfg.n_embd, cfg.n_embd, bias=False)

    def forward(s, x):
        b, T, C = x.shape
        q, k, v = [t.view(b, T, s.H, C // s.H).transpose(1, 2) for t in s.qkv(x).split(C, 2)]
        pos = torch.arange(T, device=x.device)
        q, k = rotary(q, pos, s.rot, s.base), rotary(k, pos, s.rot, s.base)
        return s.proj(F.scaled_dot_product_attention(q, k, v, is_causal=True).transpose(1, 2).reshape(b, T, C))


class Block(nn.Module):
    def __init__(s, cfg):
        super().__init__()
        s.ln1, s.attn, s.ln2, s.mlp = LayerNorm(cfg.n_embd), DenseAttn(cfg), LayerNorm(cfg.n_embd), MLP(cfg)

    def forward(s, x):
        x = x + s.attn(s.ln1(x))
        return x + s.mlp(s.ln2(x))


class DenseGPT(nn.Module):
    def __init__(s, cfg):
        super().__init__()
        s.wte = nn.Embedding(cfg.vocab_size, cfg.n_embd)
        s.blocks = nn.ModuleList([Block(cfg) for _ in range(cfg.n_layer)])
        s.ln_f = LayerNorm(cfg.n_embd)
        s.lm_head = nn.Linear(cfg.n_embd, cfg.vocab_size, bias=False)
        s.lm_head.weight = s.wte.weight
        for m in s.modules():
            if isinstance(m, (nn.Linear, nn.Embedding)):
                nn.init.normal_(m.weight, 0.0, 0.02)
        for n, p in s.named_parameters():
            if n.endswith('proj.weight'):
                nn.init.normal_(p, 0.0, 0.02 / math.sqrt(2 * cfg.n_layer))

    def forward(s, idx, targets=None, route=None):
        x = s.wte(idx)
        for blk in s.blocks:
            x = blk(x)
        lg = s.lm_head(s.ln_f(x))
        if targets is None:
            return lg, None, {}
        lm = F.cross_entropy(lg.float().view(-1, lg.size(-1)), targets.reshape(-1), ignore_index=-100)
        return lg, lm, {'lm': float(lm.detach())}


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--out', default='runs/dense')
    p.add_argument('--lengths', default='128,512,2048')
    p.add_argument('--steps_first', type=int, default=3000)
    p.add_argument('--steps', type=int, default=500)
    p.add_argument('--tokens_per_batch', type=int, default=8192)
    p.add_argument('--eval_lengths', default='4096,16384,65536')
    p.add_argument('--n_needles', type=int, default=4)
    p.add_argument('--n_queries', type=int, default=3)
    p.add_argument('--lr', type=float, default=1e-3)
    p.add_argument('--seed', type=int, default=0)
    a = p.parse_args()
    torch.manual_seed(a.seed)
    dev = 'cuda'
    task = NeedleTask(n_key=16, n_val=16, seed=a.seed)
    cfg = Config(vocab_size=task.vocab_size, n_layer=4, n_head=4, n_embd=256)
    model = DenseGPT(cfg).to(dev)
    print('DENSE control | params %.2fM' % (sum(p.numel() for p in model.parameters()) / 1e6))
    opt = torch.optim.AdamW(model.parameters(), lr=a.lr, betas=(0.9, 0.95), weight_decay=0.01)
    scaler = torch.amp.GradScaler('cuda')
    lengths = [int(v) for v in a.lengths.split(',')]
    total, step = a.steps_first + a.steps * (len(lengths) - 1), 0
    for stage, T in enumerate(lengths):
        n_steps = a.steps_first if stage == 0 else a.steps
        b, t0 = max(1, a.tokens_per_batch // T), time.time()
        for it in range(n_steps):
            for g in opt.param_groups:
                g['lr'] = a.lr * min(1.0, (step + 1) / 100) * (0.1 + 0.9 * 0.5 * (1 + math.cos(math.pi * step / total)))
            model.train()
            idx, y, _, _ = task.sample(b, T, n_needles=a.n_needles, n_queries=a.n_queries)
            with torch.autocast('cuda', dtype=torch.float16):
                _, loss, st = model(idx.to(dev), y.to(dev))
            opt.zero_grad(set_to_none=True)
            scaler.scale(loss).backward()
            scaler.unscale_(opt)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            scaler.step(opt)
            scaler.update()
            step += 1
            if it % 100 == 0 or it == n_steps - 1:
                print('T %d step %d | lm %.3f | %.2fs/step' % (T, step, st['lm'], (time.time() - t0) / (it + 1)), flush=True)
        print('  END OF STAGE T=%d | %s' % (T, fmt_row(needle_accuracy(model, task, T, depths=(0.1, 0.5, 0.9), n=24, n_needles=a.n_needles))), flush=True)
    print('\n=== FINAL (dense control; rotary extrapolation beyond the training length)')
    for T in [int(v) for v in a.eval_lengths.split(',')]:
        try:
            print('T=%6d | %s' % (T, fmt_row(needle_accuracy(model, task, T, n=32, n_needles=a.n_needles, bs=1 if T > 8192 else 2))), flush=True)
        except Exception as e:
            print('T=%6d | failed: %s' % (T, str(e)[:100]), flush=True)


if __name__ == '__main__':
    main()
