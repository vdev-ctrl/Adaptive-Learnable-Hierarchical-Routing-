"""EXTERNAL dense reference on MQAR (same model as dense_control.py, same task, same schedule as scripts/train_mqar.py).
Benchmark only, not part of the package. One configuration, from scratch, accuracy printed every --eval_every steps."""
import argparse, math, os, sys, time
import torch
here = os.path.dirname(os.path.abspath(__file__))
for pth in ('/kaggle/working/treeattn_repo', os.path.join(os.path.dirname(here), 'treeattn_repo'), here, '/kaggle/working'):
    sys.path.insert(0, pth)
from dense_control import DenseGPT
from treeattn import Config
from treeattn.evaluate import mqar_accuracy
from treeattn.tasks import MQARTask

p = argparse.ArgumentParser()
p.add_argument('--T', type=int, default=256)
p.add_argument('--n_kv', type=int, default=16)
p.add_argument('--steps', type=int, default=20000)
p.add_argument('--tokens_per_batch', type=int, default=16384)
p.add_argument('--lr', type=float, default=1e-3)
p.add_argument('--warmup', type=int, default=300)
p.add_argument('--eval_every', type=int, default=1000)
p.add_argument('--eval_n', type=int, default=32)
p.add_argument('--eval_grid', default='256:16,512:16,1024:16,4096:16,16384:16')
p.add_argument('--log_every', type=int, default=500)
p.add_argument('--save', default='')
p.add_argument('--seed', type=int, default=0)
a = p.parse_args()
torch.manual_seed(a.seed)
task = MQARTask(vocab_size=8192, seed=a.seed)
cfg = Config(vocab_size=8192, n_layer=4, n_head=4, n_embd=256)
model = DenseGPT(cfg).cuda()
print('DENSE MQAR | params %.2fM | T %d n_kv %d | %d steps x %d seqs' % (
    sum(q.numel() for q in model.parameters()) / 1e6, a.T, a.n_kv, a.steps, max(1, a.tokens_per_batch // a.T)), flush=True)
opt = torch.optim.AdamW(model.parameters(), lr=a.lr, betas=(0.9, 0.95), weight_decay=0.01)
scaler = torch.amp.GradScaler('cuda')
b, t0 = max(1, a.tokens_per_batch // a.T), time.time()
for step in range(1, a.steps + 1):
    for g in opt.param_groups:
        g['lr'] = a.lr * min(1.0, step / a.warmup) * (0.1 + 0.9 * 0.5 * (1 + math.cos(math.pi * (step - 1) / a.steps)))
    model.train()
    idx, y, _ = task.sample(b, a.T, a.n_kv)
    with torch.autocast('cuda', dtype=torch.float16):
        _, loss, st = model(idx.cuda(), y.cuda())
    opt.zero_grad(set_to_none=True)
    scaler.scale(loss).backward()
    scaler.unscale_(opt)
    torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
    scaler.step(opt)
    scaler.update()
    if step % a.log_every == 0 or step == 1:
        print('step %d | lm %.3f | %.3fs/step' % (step, st['lm'], (time.time() - t0) / step), flush=True)
    if step % a.eval_every == 0 or step == a.steps:
        print('  EVAL step %d | T=%d n_kv=%d | ACC %.3f' % (step, a.T, a.n_kv, mqar_accuracy(model, task, a.T, a.n_kv, n=a.eval_n)[0]), flush=True)
if a.save:
    torch.save(model.state_dict(), a.save)
print('\n=== FINAL dense MQAR accuracy (same weights, longer sequences; rotary extrapolation)')
for gspec in a.eval_grid.split(','):
    T, nkv = (int(v) for v in gspec.split(':'))
    try:
        print('T=%6d n_kv=%3d | acc %.3f' % (T, nkv, mqar_accuracy(model, task, T, nkv, n=a.eval_n, bs=1 if T > 4096 else 2)[0]), flush=True)
    except Exception as e:
        print('T=%6d n_kv=%3d | failed: %s' % (T, nkv, str(e)[:80]), flush=True)
