# v12 notebooks (Internet ON in both). Nothing here has been executed; the pytest line is the first run.
Same 3,000 steps x 16 x 1,024 tokens (~49M tokens), 8 layers, d=384, 6 heads, same Wikipedia token files and tokenizer in both.

## Notebook 1: our dense -> extract needles -> our tree model
```python
import glob, shutil, os
pkg = glob.glob('/kaggle/input/**/treeattn/attention.py', recursive=True)[0]
src = os.path.dirname(os.path.dirname(pkg))
shutil.rmtree('/kaggle/working/treeattn_repo', ignore_errors=True)
shutil.copytree(src, '/kaggle/working/treeattn_repo')
ext = glob.glob('/kaggle/input/**/external/dense_lm.py', recursive=True)
if ext: shutil.copytree(os.path.dirname(ext[0]), '/kaggle/working/external', dirs_exist_ok=True)
os.chdir('/kaggle/working/treeattn_repo'); os.makedirs('runs', exist_ok=True)
!pip install -q pytest
!python -m pytest tests -q -x
!python scripts/prepare_wiki.py --out /kaggle/working/data/wiki --train_tokens 55000000 --vocab 16384
!python /kaggle/working/external/dense_lm.py --repo /kaggle/working/treeattn_repo --data_dir /kaggle/working/data/wiki --out /kaggle/working/runs/lm_dense --steps 3000 --n_layer 8
!python /kaggle/working/external/extract_needles.py --repo /kaggle/working/treeattn_repo --data_dir /kaggle/working/data/wiki --dense_ckpt /kaggle/working/runs/lm_dense/ckpt.pt --out /kaggle/working/data/wiki_labels --n_windows 48000 --n_layer 8
!python scripts/train_lm.py --data_dir /kaggle/working/data/wiki --labels_dir /kaggle/working/data/wiki_labels --out runs/lm_tree --steps 3000
!python scripts/needle_eval.py --ckpt runs/lm_tree/ckpt.pt --data_dir /kaggle/working/data/wiki --out runs/demo_tree.txt
!python scripts/needle_eval.py --ckpt runs/lm_tree/ckpt.pt --data_dir /kaggle/working/data/wiki --tree_off 1 --lengths 1024,4096 --depths 0.1,0.5,0.9
!python scripts/eval_lm.py --ckpt runs/lm_tree/ckpt.pt --data_dir /kaggle/working/data/wiki --tree_off 1
!python scripts/check_decode.py --ckpt runs/lm_tree/ckpt.pt --data_dir /kaggle/working/data/wiki
!python scripts/train_mqar.py --out runs/M0 --seed 0 --T 256 --n_kv 16 --steps 1500 --spike 0 --route_weight 0.3 --wmax 32 --beam_classes 2,4,8,16,32 --max_keys 96 --q_chunk 256 --eval_every 500 --eval_n 64
```

## Notebook 2: open-source nanoGPT, same data
```python
import glob, shutil, os
pkg = glob.glob('/kaggle/input/**/treeattn/attention.py', recursive=True)[0]
src = os.path.dirname(os.path.dirname(pkg))
shutil.rmtree('/kaggle/working/treeattn_repo', ignore_errors=True)
shutil.copytree(src, '/kaggle/working/treeattn_repo')
ext = glob.glob('/kaggle/input/**/external/dense_lm.py', recursive=True)
if ext: shutil.copytree(os.path.dirname(ext[0]), '/kaggle/working/external', dirs_exist_ok=True)
os.chdir('/kaggle/working/treeattn_repo'); os.makedirs('runs', exist_ok=True)
!python scripts/prepare_wiki.py --out /kaggle/working/data/wiki --train_tokens 55000000 --vocab 16384
!git clone -q https://github.com/karpathy/nanoGPT.git /kaggle/working/nanoGPT
!python /kaggle/working/external/nanogpt_prep.py --data_dir /kaggle/working/data/wiki --out /kaggle/working/nanoGPT/data/wiki
os.chdir('/kaggle/working/nanoGPT')
!python train.py --dataset=wiki --out_dir=out-wiki --n_layer=8 --n_head=6 --n_embd=384 --block_size=1024 --batch_size=16 --gradient_accumulation_steps=1 --max_iters=3000 --lr_decay_iters=3000 --learning_rate=1e-3 --min_lr=1e-4 --warmup_iters=100 --weight_decay=0.1 --beta2=0.95 --dropout=0.0 --bias=False --dtype=float16 --compile=False --eval_interval=500 --eval_iters=100 --log_interval=50
os.chdir('/kaggle/working/treeattn_repo')
!python /kaggle/working/external/nanogpt_eval.py --repo /kaggle/working/treeattn_repo --nanogpt /kaggle/working/nanoGPT --ckpt /kaggle/working/nanoGPT/out-wiki/ckpt.pt --data_dir /kaggle/working/data/wiki --out runs/demo_nanogpt.txt
```
Use Save Version -> Save & Run All. If the tree step time (printed every 50 steps) is above ~6 s, lower --steps (and --n_windows to steps x 16) before the long part.
