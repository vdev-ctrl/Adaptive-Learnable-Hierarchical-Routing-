# past/ : everything retired from the clean repo

Snapshot of v12 exactly as it was, runnable on its own, plus the notebook cells of that round.

- `v12_repo/`  the v12 repo. Retired features and where they live:
  - spike detector + gate, amplification, early-token boost: `treeattn/spike.py`, and the spike code paths in `treeattn/attention.py` (it diverged on PG-19; off by default in v12)
  - needle-based routing: `route_loss` in `treeattn/tree.py`, `route=` / `hit` hooks in `treeattn/attention.py` and `model.py`, label loading in `treeattn/lmdata.py` (`load_labels`, `labeled_batch`)
  - synthetic training tasks: `treeattn/tasks.py` (needle, MQAR), `evaluate.py`, `scripts/train_mqar.py`, `train_needle.py`, `eval_needle.py`, `diagnose_mqar.py`, `prepare_data.py`
  - test hooks: `tree_off`, `abs_pos`, `scripts/probe_rope.py`
  - `CHANGELOG.md` / `README.md` of v12 (records)
- `v12_external/`  external dense baseline and the needle extractor: `extract_needles.py`, `dense_lm.py`, `dense_model.py`, `dense_control.py`, `dense_mqar.py`, `nanogpt_*.py`
- `v12_KAGGLE_CELLS.md`  the v12 notebook cells

- `v13_two_phase_draft/`  `train_dense.py` and `train_tree.py` of the first v13 cut: two phases, where the second one trained the tree on next-word loss and the dense-attention losses at the same time (FFN at 0.1x). Replaced by the three-phase pipeline (distillation on its own, then standard training).

Why they were retired: the final design trains the tree against the dense model's full attention matrix instead of extracted needles, so the needle pipeline, the spike amplification that served it, and the hooks used to debug them are no longer part of the core.
To reproduce a v12 result, run it from `v12_repo/` (it needs `v12_external/` next to it, as before).
