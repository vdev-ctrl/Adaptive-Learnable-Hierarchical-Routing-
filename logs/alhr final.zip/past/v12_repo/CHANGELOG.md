# Changelog

## v12
- The repo contains NO dense attention: the dense warm-up, the full-matrix guide and every scaled_dot_product_attention call are gone
  (a test scans the source for them). Training and inference are the same sub-quadratic code.
- Routing labels now come from outside: an external dense model is trained first (external/dense_lm.py), then
  external/extract_needles.py runs it once over the training windows and writes (query, key) label rows per window and layer.
  scripts/train_lm.py --labels_dir reads them and trains the tree model with the same contrastive routing loss the MQAR runs used,
  from step 0. Layer l of the tree uses the labels of layer l of the dense model.
- Larger read budget is the default for LM runs: --wmax 32 --beam_classes 2,4,8,16,32 --max_keys 96 --q_chunk 256.
- Wikipedia data (scripts/prepare_wiki.py), a needle-in-Wikipedia test (treeattn/needles.py, scripts/needle_eval.py) with controls,
  free prompts printed with the model's answers, --tree_off ablation (scripts/eval_lm.py, needle_eval.py), abort after 20 non-finite steps.
- External nanoGPT baseline: external/nanogpt_prep.py (same token files) and external/nanogpt_eval.py (same windows, needles, prompts).
- Spike stays in the code (scale 'levels') but is off by default; it diverged on PG-19.

## v11
- Spike amplification proportional to tree levels (--spike_scale levels). Class histogram in the logs.

## Pinned
- Budget labels from the dense row (instead of "smallest class covering 90% of the tree's own candidates").
