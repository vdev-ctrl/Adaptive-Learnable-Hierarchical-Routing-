"""Needle-in-a-haystack task (token level, any length).

Sequence layout (x has T + 1 tokens, input = x[:T], target = x[1:]):
    filler ... [SEP K V1 V2 V3] ... filler ... (distractor needles with other keys) ... [QRY K] V1 V2 V3
The loss is only on the three value tokens at the end. The model has to find the needle whose key matches the
question, at any depth, in a haystack of up to 64k+ tokens. Filler is random Zipf-like tokens, or real text tokens
if `filler_bin` (uint16 token file, ids < n_filler) is given.

Vocabulary: [0, n_filler) filler, then SEP, QRY, IS (reserved, unused), then n_key key tokens, then n_val value tokens.
"""
import numpy as np
import torch

KEY_LEN, VAL_LEN = 1, 3
NEEDLE_LEN = 1 + KEY_LEN + VAL_LEN             # SEP K V1 V2 V3
QUERY_LEN = 1 + KEY_LEN + VAL_LEN              # QRY K  -> V1 V2 V3 (classic induction: copy what followed K)


class NeedleTask:
    def __init__(self, n_filler=8192, n_key=64, n_val=64, filler_bin=None, seed=0):
        self.n_filler, self.n_key, self.n_val = n_filler, n_key, n_val
        self.SEP, self.QRY, self.IS = n_filler, n_filler + 1, n_filler + 2
        self.key0, self.val0 = n_filler + 3, n_filler + 3 + n_key
        self.vocab_size = self.val0 + n_val
        self.rng = np.random.default_rng(seed)
        self.filler = np.memmap(filler_bin, dtype=np.uint16, mode='r') if filler_bin else None
        if self.filler is None:
            p = 1.0 / np.arange(1, n_filler + 1)
            self.p = p / p.sum()

    def _filler(self, n):
        if self.filler is not None:
            i = int(self.rng.integers(0, len(self.filler) - n - 1))
            return np.minimum(self.filler[i:i + n].astype(np.int64), self.n_filler - 1)
        return self.rng.choice(self.n_filler, size=n, p=self.p)

    def sample(self, b, T, n_needles=4, depth=None, n_queries=1):
        """Returns idx (b,T), targets (b,T) (-100 except the answer slots), route = (qpos, tgt) for the FIRST question,
        answers (b,3) of the LAST question. n_queries distinct needles are asked at the end (more graded tokens per
        sequence for training; evaluation uses n_queries=1). depth in [0,1] places the first question's needle."""
        assert n_queries <= n_needles and n_needles * VAL_LEN <= self.n_val and T > NEEDLE_LEN * (n_needles + 1) + QUERY_LEN * n_queries + 8
        slot = T + 1 - QUERY_LEN * n_queries - n_needles * NEEDLE_LEN      # number of filler tokens
        xs, qpos, tgt = [], [], []
        for _ in range(b):
            keys = self.rng.choice(self.n_key ** KEY_LEN, size=n_needles, replace=False)
            vals = self.rng.choice(self.n_val, size=n_needles * VAL_LEN, replace=False).reshape(n_needles, VAL_LEN)   # distinct: no collisions
            cuts = self.rng.integers(0, slot + 1, size=n_needles)
            asked = self.rng.permutation(n_needles)[:n_queries]               # needle ids, in question order
            if depth is not None:
                cuts[asked[0]] = int(depth * slot)
            order = np.argsort(cuts, kind='stable')
            inv = np.empty(n_needles, dtype=int)
            inv[order] = np.arange(n_needles)                                   # old id -> sorted slot
            cuts, keys, vals = cuts[order], keys[order], vals[order]
            asked = [int(inv[i]) for i in asked]
            filler = self._filler(slot)

            def ktoks(j):
                return [self.key0 + (int(keys[j]) // self.n_key ** (KEY_LEN - 1 - m)) % self.n_key for m in range(KEY_LEN)]

            def vtoks(j):
                return [self.val0 + int(v) for v in vals[j]]
            seq, used, tpos = [], 0, 0
            for j in range(n_needles):
                seq.append(filler[used:cuts[j]])
                used = int(cuts[j])
                if j == asked[0]:
                    tpos = sum(len(x) for x in seq)
                seq.append(np.array([self.SEP] + ktoks(j) + vtoks(j), dtype=np.int64))
            seq.append(filler[used:])
            for j in asked:
                seq.append(np.array([self.QRY] + ktoks(j) + vtoks(j), dtype=np.int64))
            full = np.concatenate(seq)
            assert len(full) == T + 1, (len(full), T + 1)
            xs.append(full)
            qpos.append(T + 1 - QUERY_LEN * n_queries + KEY_LEN)               # input position of the first question's key token
            tgt.append(tpos + 1 + KEY_LEN)                                      # position of V1 inside that needle
        X = torch.from_numpy(np.stack(xs))
        idx, y = X[:, :T].clone(), X[:, 1:].clone()
        mask = torch.full_like(y, -100)
        for qn in range(n_queries):
            s0 = T + 1 - QUERY_LEN * (n_queries - qn) + KEY_LEN                 # x index of the question's key token
            mask[:, s0:s0 + VAL_LEN] = y[:, s0:s0 + VAL_LEN]
        return idx, mask, (torch.tensor(qpos), torch.tensor(tgt)), X[:, -VAL_LEN:].clone()


class MQARTask:
    """Multi-query associative recall (Arora et al., "Zoology"), generated as in the published recipe:
    n_kv unique key->value pairs first (keys from the lower half of the vocabulary, values from the upper half), then
    every key is queried once at a power-law-distributed gap among random filler tokens; the model must output the
    value right after each queried key. Loss only on those answer positions.
    route = (bidx, qpos, tgt) with one row per query: qpos = position of the queried key, tgt = position of its value."""

    def __init__(self, vocab_size=8192, power_a=0.01, seed=0):
        self.V, self.a = vocab_size, power_a
        self.rng = np.random.default_rng(seed)

    def sample(self, b, T, n_kv):
        V, rng = self.V, self.rng
        ctx = 2 * n_kv
        space = (T - ctx) // 2
        assert T % 2 == 0 and space >= n_kv, 'need T even and (T - 2 n_kv) / 2 >= n_kv'
        p = self.a * np.arange(1, space + 1) ** (self.a - 1.0)
        p = p / p.sum()
        X, Y, bi, qp, tg = [], [], [], [], []
        for j in range(b):
            keys = rng.choice(np.arange(1, V // 2), n_kv, replace=False)
            vals = rng.choice(np.arange(V // 2, V), n_kv, replace=False)
            kvs = np.zeros(ctx, dtype=np.int64)
            kvs[0::2], kvs[1::2] = keys, vals
            gaps = rng.choice(space, size=n_kv, replace=False, p=p)
            queries = np.zeros(T - ctx + 1, dtype=np.int64)
            queries[gaps * 2] = keys
            labels = np.full(T + 1, -100, dtype=np.int64)
            labels[gaps * 2 + ctx + 1] = vals
            ex = np.concatenate([kvs, queries])
            x, y = ex[:-1].copy(), labels[1:]
            zero = x == 0
            x[zero] = rng.integers(1, V, size=int(zero.sum()))
            X.append(x), Y.append(y)
            bi += [j] * n_kv
            qp += list(gaps * 2 + ctx)
            tg += list(2 * np.arange(n_kv) + 1)
        return (torch.from_numpy(np.stack(X)), torch.from_numpy(np.stack(Y)),
                (torch.tensor(bi), torch.tensor(qp), torch.tensor(tg)))
