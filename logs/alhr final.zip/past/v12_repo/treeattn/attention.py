"""Sub-quadratic causal tree attention.

Trainable parts (everything else is parameter-free search):
  1. the splitter: one linear map x -> q, k, v
  2. the budget predictor: a small MLP (query + anti-dilution global vector -> how many leaf groups are needed)

Per query, in order: static keys (sink, self, previous local-1) -> neighbour search (borrow from earlier queries)
-> tree descent for whatever the budget still needs. Exact softmax attention runs only over the (<= max_keys)
selected keys. No dense T x T matrix exists anywhere. Training and decoding use the same functions; decoding keeps a
LayerCache (keys, values, tree levels, global sum, stored leaves) and costs O(wmax * log T + max_keys) per token.

The spike detector looks at the layer input x BEFORE the splitter (see spike.py), so the amplification of a key is a
function of the token and is trainable through the routing loss.

Position handling: the first `rot_dims` dims of every head are rotated (RoPE) and used by exact attention only; the
remaining content dims are what the tree indexes. The tree therefore sums position-free content vectors.
"""
import math

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.checkpoint import checkpoint

from .spike import Spike
from .tree import (build_levels, gather_nodes, n_levels, neighbor_search, next_pow2, route_loss, select_unique,
                   split_budget, tree_descent)


class LayerCache:
    def __init__(self, cfg, b, tmax, device, dtype):
        H, dh, dc = cfg.n_head, cfg.head_dim, cfg.content_dim
        self.tmax, self.tpad = tmax, next_pow2(tmax)
        self.k = torch.zeros(b, H, tmax, dh, device=device, dtype=dtype)
        self.v = torch.zeros(b, H, tmax, dh, device=device, dtype=dtype)
        self.qc = torch.zeros(b, H, tmax, dc, device=device)
        self.S = build_levels(torch.zeros(b, H, self.tpad, dc, device=device), self.tpad)
        self.G = torch.zeros(b, H, dc, device=device)
        self.tops = torch.full((b, H, tmax, cfg.nb_store), -1, dtype=torch.long, device=device)
        self.x = torch.zeros(b, tmax, cfg.n_embd, device=device)                      # layer inputs (spike window)
        self.gx = torch.zeros(b, cfg.n_embd, device=device, dtype=torch.float64)      # running sum of x over positions >= 1
        self.gx2 = torch.zeros(b, cfg.n_embd, device=device, dtype=torch.float64)     # running sum of x^2
        self.t = 0


def rotary(x, pos, rot, base):
    if rot == 0:
        return x
    inv = 1.0 / (base ** (torch.arange(0, rot, 2, device=x.device).float() / rot))
    ang = pos.float().view(-1, 1) * inv.view(1, -1)
    cos, sin = ang.cos().to(x.dtype), ang.sin().to(x.dtype)
    x1, x2, rest = x[..., :rot // 2], x[..., rot // 2:rot], x[..., rot:]
    return torch.cat([x1 * cos - x2 * sin, x1 * sin + x2 * cos, rest], -1)


def rotate_extra(x, extra, rot, base):
    """Rotate the first `rot` dims of x (..., dh) by an additional per-element position `extra` (x.shape[:-1]).
    Keys are stored rotated by their absolute position j and queries by t, so the score sees R((j - t) * theta).
    Adding extra = max(t - j - cap, 0) to the key makes the score see R(-min(t - j, cap) * theta): relative distance capped."""
    inv = 1.0 / (base ** (torch.arange(0, rot, 2, device=x.device).float() / rot))
    ang = extra.float().unsqueeze(-1) * inv
    cos, sin = ang.cos().to(x.dtype), ang.sin().to(x.dtype)
    x1, x2, rest = x[..., :rot // 2], x[..., rot // 2:rot], x[..., rot:]
    return torch.cat([x1 * cos - x2 * sin, x1 * sin + x2 * cos, rest], -1)


class TreeAttention(nn.Module):
    def __init__(self, cfg, layer=0):
        super().__init__()
        self.cfg, self.layer = cfg, layer
        C, H = cfg.n_embd, cfg.n_head
        self.H, self.dh, self.dc, self.rot = H, cfg.head_dim, cfg.content_dim, cfg.rot_dims
        assert C % H == 0 and self.dc > 0 and self.rot % 2 == 0
        assert cfg.wmax >= cfg.nb_store and max(cfg.beam_classes) <= cfg.wmax
        self.qkv = nn.Linear(C, 3 * C, bias=False)          # the splitter
        self.proj = nn.Linear(C, C, bias=False)
        self.spike = Spike(cfg)
        if cfg.budget_mode == 'pred':                       # the budget predictor
            fin = self.dc + 1 + H + self.dc + 1
            self.pred = nn.Sequential(nn.Linear(fin, cfg.pred_hidden), nn.ReLU(),
                                      nn.Linear(cfg.pred_hidden, len(cfg.beam_classes)))
            self.register_buffer('classes', torch.tensor(list(cfg.beam_classes)), persistent=False)
            self.register_buffer('head_eye', torch.eye(H), persistent=False)
        self.aux = {}

    # ------------------------------------------------------------------ retroactive boost of the first tokens
    def _early_delta(self, x, kc, n_total, cache, t0, T, decode):
        """The first spike_min_hist - 1 tokens (positions 1..m-1) have no history, so the online score cannot flag them.
        Once position m-1 has been seen they are scored (leave-one-out) and the extra index mass
        delta = sum_j (mult_j - 1) * key_j  is added to the tree nodes that cover them and are only readable by queries
        t >= 2**L0 >= m (L0 = ceil(log2 m)), and to the global vector of queries t >= m. Every such query has already seen
        positions 0..m-1, so nothing from its future is used; queries t < m never see the boost. Because all of positions
        < m sit inside node 0 of every level >= L0, the whole update is ONE (b,H,dc) vector added to node 0 per level.
        Returns delta (b,H,dc) or None when it is not due in this call."""
        m = self.cfg.spike_min_hist
        if decode:
            if t0 != m - 1:
                return None
            xe, ke = cache.x[:, 1:m], cache.k[:, :, 1:m, self.rot:].float()
        else:
            if T < m or m < 2:
                return None
            xe, ke = x[:, 1:m], kc[:, :, 1:m].float()
        s_e = self.spike.early_scores(xe)                                         # (b, m-1)
        if self.spike.thr_init.item() == 0:
            return None
        extra = (self.spike.multiplier(s_e, n_total) - 1.0).unsqueeze(1).unsqueeze(-1)   # (b,1,m-1,1)
        return torch.nan_to_num((ke * extra).sum(2), nan=0.0, posinf=1e4, neginf=-1e4)  # (b,H,dc)

    def _apply_delta(self, delta, S, cache_G, G):
        """cache_G given: decoding, add in place to the cache. Otherwise S is a local list (replaced with copies, keeps the
        gradient) and G (b,H,T,dc) gets the delta for queries t >= spike_min_hist."""
        L0 = max((self.cfg.spike_min_hist - 1).bit_length(), 1)
        for l in range(L0, len(S)):
            if cache_G is not None:
                S[l][:, :, 0] += delta
            else:
                S[l] = torch.cat([S[l][:, :, :1] + delta.unsqueeze(2), S[l][:, :, 1:]], 2)
        if cache_G is not None:
            cache_G += delta
        else:
            T = G.shape[2]
            G += delta.detach().unsqueeze(2) * (torch.arange(T, device=G.device) >= self.cfg.spike_min_hist).view(1, 1, T, 1).to(G.dtype)

    # ------------------------------------------------------------------ budget predictor
    def _budget(self, qc, G):
        """qc (b,H,N,dc) content queries, G (b,H,N,dc) anti-dilution global vector (sum of all earlier index keys,
        spikes included at their amplified value). Returns (leaf-group budget (b,H,N) long, logits or None)."""
        b, H, N, _ = qc.shape
        if self.cfg.budget_mode != 'pred':
            return torch.full((b, H, N), self.cfg.fixed_budget, dtype=torch.long, device=qc.device), None
        qd, gn = qc.detach().float(), G.detach().float().norm(dim=-1, keepdim=True)
        feats = torch.cat([qd, torch.log(qd.norm(dim=-1, keepdim=True) + 1e-6),
                           self.head_eye.view(1, H, 1, H).expand(b, H, N, H),
                           G.detach().float() / (gn + 1e-6), torch.log1p(gn) / 10.0], -1)
        logits = self.pred(feats)
        return self.classes[logits.argmax(-1).detach()], logits

    # ------------------------------------------------------------------ exact attention over selected keys
    def _exact(self, q, kbuf, vbuf, pos, ok, tqc=None):
        p = pos.clamp(0, kbuf.shape[2] - 1)                     # masked slots may point past the buffer
        kg, vg = gather_nodes(kbuf, p), gather_nodes(vbuf, p)
        cap = self.cfg.rope_cap
        if cap > 0 and self.rot > 0 and tqc is not None:         # diagnostic: no key looks farther away than `cap` positions
            kg = rotate_extra(kg, (tqc.view(1, 1, -1, 1) - p - cap).clamp(min=0), self.rot, self.cfg.rope_base)
        s = torch.einsum('bhnd,bhnkd->bhnk', q, kg).float() / math.sqrt(q.shape[-1])
        w = torch.softmax(s.masked_fill(~ok, float('-inf')), -1).to(vg.dtype)
        return torch.einsum('bhnk,bhnkd->bhnd', w, vg)

    @torch.no_grad()
    def _budget_label(self, q, kbuf, tree_pos, tree_ok, st, st_ok, cl):
        """Smallest class that covers 90% of the tree-leaf attention mass (leaves taken in search order).
        Also returns the share of attention the tree leaves get (weight for the loss)."""
        def sc(p):
            return torch.einsum('bhnd,bhnkd->bhnk', q.float(), gather_nodes(kbuf, p.clamp(0, kbuf.shape[2] - 1)).float()) / math.sqrt(q.shape[-1])
        logit = torch.cat([sc(st).masked_fill(~st_ok, float('-inf')), sc(tree_pos).masked_fill(~tree_ok, float('-inf'))], -1)
        w = torch.softmax(logit, -1)[..., st.shape[-1]:]
        mass = w[..., 0::2] + w[..., 1::2]
        total = mass.sum(-1)
        need = (mass.cumsum(-1) < 0.9 * total.unsqueeze(-1)).sum(-1) + 1
        label = (need.unsqueeze(-1) > cl).sum(-1).clamp(max=len(cl) - 1)
        return label, total

    # ------------------------------------------------------------------ forward
    def forward(self, x, cache=None, route=None):
        if isinstance(route, list):                                  # per-layer labels (e.g. extracted from a dense model)
            route = route[self.layer]
        cfg = self.cfg
        b, T, C = x.shape
        H, dh, dc, rot = self.H, self.dh, self.dc, self.rot
        dev = x.device
        self.aux = {}
        q, k, v = [t.view(b, T, H, dh).transpose(1, 2) for t in self.qkv(x).split(C, 2)]
        t0 = cache.t if cache is not None else 0
        decode = cache is not None and t0 > 0
        assert not decode or T == 1, 'cached decoding takes one token at a time (prefill the prompt first)'
        tq = torch.arange(t0, t0 + T, device=dev)
        q, k = rotary(q, tq, rot, cfg.rope_base), rotary(k, tq, rot, cfg.rope_base)

        # ---- buffers visible to this call
        if cache is not None:
            cache.k[:, :, t0:t0 + T], cache.v[:, :, t0:t0 + T] = k.to(cache.k.dtype), v.to(cache.v.dtype)
            cache.qc[:, :, t0:t0 + T] = q[..., rot:].detach().float()
            kbuf, vbuf, qbuf = cache.k[:, :, :t0 + T], cache.v[:, :, :t0 + T], cache.qc[:, :, :t0 + T]
        else:
            kbuf, vbuf, qbuf = k, v, q[..., rot:].detach().float()

        # ---- spike detection on the tokens (before the splitter) and graded amplification (index sums only)
        kc = k[..., rot:]
        if cache is not None:
            cache.x[:, t0:t0 + T] = x.detach().float()
        if cfg.spike:
            if decode:
                lo = max(1, t0 - cfg.spike_win)
                st = self.spike.stats_step(cache.x[:, lo:t0], cache.gx, cache.gx2, t0 - 1)
            else:
                st = self.spike.stats_parallel(x)
            s, sg = self.spike.scores(x, st)
            if self.training and not decode:
                self.spike.update(s.detach(), sg)
            n_total = cache.tpad if cache is not None else next_pow2(T)      # window size, same in training and decoding
            mult = self.spike.multiplier(s, n_total).unsqueeze(1).expand(b, H, T)
            self.aux['flag_frac'] = self.spike.flag_frac(s)
            if cache is not None:
                xd = x.detach().double()
                if decode:
                    cache.gx += xd[:, 0]
                    cache.gx2 += xd[:, 0] ** 2
                else:
                    cache.gx, cache.gx2 = xd[:, 1:].sum(1), (xd[:, 1:] ** 2).sum(1)
        else:
            mult = torch.ones(b, H, T, device=dev)
        kidx = torch.nan_to_num(kc.float() * mult.unsqueeze(-1), nan=0.0, posinf=1e4, neginf=-1e4)
        kidx = kidx * (tq != 0).view(1, 1, T, 1).to(kidx.dtype)            # the sink is never indexed

        # ---- retroactive boost of the first spike_min_hist tokens (causal: see _early_delta)
        delta = self._early_delta(x, kc, n_total, cache, t0, T, decode) if cfg.spike and cfg.spike_early else None

        # ---- tree levels + anti-dilution global vector
        use_route = route is not None and self.training and self.layer >= cfg.route_min_layer and cfg.route_weight > 0
        if decode:
            for l in range(1, len(cache.S)):
                cache.S[l][:, :, t0 >> l] += kidx[:, :, 0]
            S, G = cache.S, cache.G.view(b, H, 1, dc).clone()
            cache.G += kidx[:, :, 0]
            if delta is not None:                                    # token m-1 just arrived: the early tokens become scoreable
                self._apply_delta(delta, S, cache.G, None)
            tpad = cache.tpad
        else:
            tpad = cache.tpad if cache is not None else next_pow2(T)
            with torch.set_grad_enabled(use_route):
                S = build_levels(kidx, tpad)
            kd = kidx.detach()
            G = kd.cumsum(2) - kd
            if delta is not None:
                S = list(S)
                self._apply_delta(delta, S, None, G)
            if cache is not None:
                cache.S = [None] + [s_.detach().clone() for s_ in S[1:]]
                cache.G = kd.sum(2) + (delta.detach() if delta is not None else 0.0)
        Sd = [None] + [s_.detach() for s_ in S[1:]]

        # ---- budget predictor
        lhat, plog = self._budget(qbuf[:, :, t0:t0 + T], G)
        if plog is not None and not decode:                                # share of queries per budget class (for the log)
            self.aux['chist'] = (plog.argmax(-1).unsqueeze(-1) == torch.arange(plog.shape[-1], device=dev)).float().mean((0, 1, 2)).detach()

        # ---- pass 1: tree descent for every query; each query stores its best leaves for its neighbours
        NS, chunk = cfg.nb_store, cfg.q_chunk
        spans = [(s0, min(s0 + chunk, T)) for s0 in range(0, T, chunk)]
        qf = qbuf[:, :, t0:t0 + T]
        tops = cache.tops if cache is not None else torch.full((b, H, T, NS), -1, dtype=torch.long, device=dev)
        found = []
        for s0, s1 in spans:
            ids, vld, _ = tree_descent(qf[:, :, s0:s1], Sd, tq[s0:s1], cfg.wmax, cfg.node_norm)
            found.append((ids, vld))
            tops[:, :, t0 + s0:t0 + s1] = torch.where(vld[..., :NS], ids[..., :NS], torch.full_like(ids[..., :NS], -1))

        if route is not None:
            bidx, qpos_r, tgt_r = route if len(route) == 3 else (torch.arange(b, device=dev), route[0], route[1])
        # ---- pass 2: neighbour search, budget split, key selection, exact attention
        outs, st_keys, st_tree, st_nb = [], 0.0, 0.0, 0.0
        pnum, pden = 0.0, 0.0
        hit_num, hit_den = 0.0, 0.0
        ar_w = torch.arange(found[0][0].shape[-1], device=dev)
        lvk = 1 << cfg.nb_level
        for (s0, s1), (ids, vld) in zip(spans, found):
            n, tqc = s1 - s0, tq[s0:s1]
            grp, match, nL = neighbor_search(qf[:, :, s0:s1], qbuf, Sd, tqc, tops, cfg)
            n_tree = split_budget(lhat[:, :, s0:s1], nL, cfg.wmax)
            leaf_ok = vld & (ar_w[:ids.shape[-1]] < n_tree.unsqueeze(-1))
            if cfg.tree_off:                                        # ablation: read no tree leaves (static + neighbour keys only)
                leaf_ok = leaf_ok & False
            tree_pos = (2 * ids.unsqueeze(-1) + torch.arange(2, device=dev)).flatten(-2)
            nb_pos = (grp.unsqueeze(-1) * lvk + torch.arange(lvk, device=dev)).flatten(-2)
            st = (tqc.view(1, 1, n, 1) - torch.arange(cfg.local, device=dev)).expand(b, H, n, cfg.local)
            st = torch.cat([torch.zeros(b, H, n, 1, dtype=torch.long, device=dev), st], -1)
            st_ok = st >= 0
            cand = torch.cat([st, tree_pos, nb_pos], -1)
            valid = torch.cat([st_ok, leaf_ok.repeat_interleave(2, -1), match.repeat_interleave(lvk, -1)], -1)
            pos, ok = select_unique(cand, valid, cfg.max_keys)
            if route is not None:                                  # diagnostic: is the needle among the keys this layer reads?
                inc = (qpos_r >= s0) & (qpos_r < s1)
                ic = (qpos_r - s0).clamp(0, n - 1)
                h = ((pos[bidx, :, ic] == tgt_r.view(-1, 1, 1)) & ok[bidx, :, ic]).any(-1).any(1)
                hit_num = hit_num + (h & inc).sum().float()
                hit_den = hit_den + inc.sum().float()
            qc_rows = q[:, :, s0:s1]
            if self.training and qc_rows.requires_grad:
                outs.append(checkpoint(self._exact, qc_rows, kbuf, vbuf, pos, ok, tqc, use_reentrant=False))
            else:
                outs.append(self._exact(qc_rows, kbuf, vbuf, pos, ok, tqc))
            if self.training and plog is not None:
                label, share = self._budget_label(qc_rows, kbuf, tree_pos, vld.repeat_interleave(2, -1), st, st_ok, self.classes)
                ce = F.cross_entropy(plog[:, :, s0:s1].float().reshape(-1, plog.shape[-1]), label.reshape(-1), reduction='none')
                pnum = pnum + (ce * share.reshape(-1)).sum()
                pden = pden + share.sum()
            st_keys = st_keys + ok.sum(-1).float().sum()
            st_tree = st_tree + leaf_ok.sum(-1).float().sum()
            st_nb = st_nb + nL.float().sum()
        denom = float(b * H * T)
        self.aux['keys'] = (st_keys / denom).detach()
        self.aux['leaves_used'] = (st_tree / denom).detach()
        self.aux['nb_leaves'] = (st_nb / denom).detach()
        if route is not None:
            self.aux['hit'] = (hit_num / (hit_den + 1e-6)).detach()
        if self.training and plog is not None:
            self.aux['pred'] = pnum / (pden + 1e-6)
        if use_route:
            q_row = q[bidx, :, qpos_r][..., rot:]
            self.aux['route'] = route_loss(q_row, S, bidx, qpos_r, tgt_r, cfg.route_neg, cfg.node_norm)
        if cache is not None:
            cache.t = t0 + T
        out = torch.cat(outs, 2)
        return self.proj(out.transpose(1, 2).reshape(b, T, C))
