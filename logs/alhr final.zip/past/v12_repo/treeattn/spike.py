"""Spike detector on the TOKENS (the layer input x, before the splitter) + graded amplification of index keys.

Why before the splitter: the keys are produced by the learned splitter from x. If the spike decision is a function of x,
then the multiplier that scales a key inside the tree sums is differentiable with respect to x, i.e. with respect to the
embeddings and every earlier layer. The routing loss can therefore teach the network to make needle tokens
spiky, instead of hoping that they already are.

Score of token t (one scalar per token, shared by all heads), using only positions < t (causal, constant-size look-back):
  local  score s_loc : RMS over dims of (x_t - trailing mean) / trailing std, trailing window = previous `spike_win` tokens.
  global score s_glb : the same z-score against the running mean/std of ALL earlier tokens (from running sums).
  gate   = sigmoid(gate_sharp * (s_glb / glb_thr - 1))   a LOOSE range: tokens that sit inside the typical global
           range are damped, tokens outside it pass. glb_thr is a low running quantile (spike_gq, default the median).
  s      = s_loc * gate                                     the local gradient decides, the global sum only narrows it.
Position 0 (attention sink) is never part of any statistic and is never indexed.

Amplification (graded, smooth):
  e    = clamp((softplus(soft*(s/thr - 1)) - softplus(-soft)) / soft, max = spike_cap)      e = 0 at s = 0, ~relu(s/thr-1) above
  mult = 1 + spike_amp * scale * e          scale = d (content dims) or sqrt(N) with N = total window size (padded tree size), the same for every token
Smooth (not a hard relu) so that tokens below the threshold still receive gradient and can learn to become spikes.
Only the index sums see `mult`; the stored key used by exact attention is unchanged.
thr (quantile `spike_q` of s) and glb_thr are running estimates updated in training and frozen at inference.
Window / global statistics are constants (no gradient); gradient flows through the current token only.
"""
import math

import torch
import torch.nn as nn
import torch.nn.functional as F

EPS_VAR = 1e-4


def _rms(z):
    return (z.pow(2).mean(-1) + 1e-8).sqrt()


class Spike(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        self.register_buffer('thr', torch.zeros(1))
        self.register_buffer('gthr', torch.zeros(1))
        self.register_buffer('thr_init', torch.zeros(1))

    # ------------------------------------------------------------------ statistics (no gradient)
    @torch.no_grad()
    def stats_parallel(self, x):
        """x (b,T,C) for positions 0..T-1. Prefix sums in float64: O(T*C), no window gather."""
        W = self.cfg.spike_win
        b, T, C = x.shape
        xd = x.detach().double()
        xd = torch.cat([torch.zeros_like(xd[:, :1]), xd[:, 1:]], 1)                  # sink excluded
        P = F.pad(xd.cumsum(1), (0, 0, 1, 0))                                         # P[i] = sum_{j<i} x_j
        P2 = F.pad((xd * xd).cumsum(1), (0, 0, 1, 0))
        t = torch.arange(T, device=x.device)
        lo = torch.minimum((t - W).clamp(min=1), t)                                   # window = [lo, t)
        n = t - lo
        nn_ = n.clamp(min=1).view(1, T, 1).double()
        mu = (P[:, :T] - P[:, lo]) / nn_
        var = ((P2[:, :T] - P2[:, lo]) / nn_ - mu * mu).clamp(min=0)
        gn = (t - 1).clamp(min=1).view(1, T, 1).double()                               # global = positions 1..t-1
        gm = P[:, :T] / gn
        gv = (P2[:, :T] / gn - gm * gm).clamp(min=0)
        return mu.float(), (var + EPS_VAR).sqrt().float(), n, gm.float(), (gv + EPS_VAR).sqrt().float()

    @torch.no_grad()
    def stats_step(self, xwin, gsum, gsum2, gcnt):
        """Decoding, one token. xwin (b,n,C) = the previous window (positions max(1,t-W)..t-1), gsum/gsum2 (b,C) float64
        running sums over positions 1..t-1, gcnt = t-1. Returns the same tuple as stats_parallel (T = 1)."""
        b, n, C = xwin.shape
        dev = gsum.device
        if n > 0:
            xw = xwin.double()
            mu = xw.sum(1) / n
            var = ((xw * xw).sum(1) / n - mu * mu).clamp(min=0)
        else:
            mu, var = torch.zeros(b, C, device=dev, dtype=torch.float64), torch.zeros(b, C, device=dev, dtype=torch.float64)
        g = max(gcnt, 1)
        gm = gsum / g
        gv = (gsum2 / g - gm * gm).clamp(min=0)
        return (mu.float().unsqueeze(1), (var + EPS_VAR).sqrt().float().unsqueeze(1), torch.tensor([n], device=dev),
                gm.float().unsqueeze(1), (gv + EPS_VAR).sqrt().float().unsqueeze(1))

    # ------------------------------------------------------------------ scores
    def scores(self, x, st):
        """x (b,T,C) with grad, st from stats_*. Returns (s, s_glb), both (b,T); zero until `spike_min_hist` earlier tokens exist."""
        mu, sd, n, gm, gsd = st
        xf = x.float()
        s_loc = _rms((xf - mu) / sd)
        s_glb = _rms((xf - gm) / gsd)
        if self.cfg.spike_gate and self.thr_init.item() != 0:
            gate = torch.sigmoid(self.cfg.gate_sharp * (s_glb / self.gthr.clamp(min=1e-3) - 1.0))
        else:
            gate = torch.ones_like(s_loc)
        s = torch.nan_to_num(s_loc * gate, nan=0.0, posinf=1e3).clamp(max=1e3)
        valid = (n >= self.cfg.spike_min_hist).view(1, -1).to(s.dtype)
        return s * valid, s_glb.detach() * valid

    @torch.no_grad()
    def update(self, s, sg):
        """EMA of the running quantiles (training only). s, sg (b,T)."""
        c = self.cfg
        x = s[:, c.spike_min_hist + 1:].reshape(-1).float()
        g = sg[:, c.spike_min_hist + 1:].reshape(-1).float()
        if x.numel() == 0:
            return
        if x.numel() > 1_000_000:
            sel = torch.randperm(x.numel(), device=x.device)[:1_000_000]
            x, g = x[sel], g[sel]
        qv = torch.quantile(torch.nan_to_num(x, nan=0.0, posinf=1e3), c.spike_q).view(1)
        qg = torch.quantile(torch.nan_to_num(g, nan=0.0, posinf=1e3), c.spike_gq).view(1)
        if not (torch.isfinite(qv).all() and torch.isfinite(qg).all()):
            return
        if self.thr_init.item() == 0:
            self.thr.copy_(qv)
            self.gthr.copy_(qg)
            self.thr_init.fill_(1.0)
        else:
            self.thr.mul_(c.spike_ema).add_(qv * (1 - c.spike_ema))
            self.gthr.mul_(c.spike_ema).add_(qg * (1 - c.spike_ema))

    def multiplier(self, s, n_total):
        """s (b,T) -> multiplier (b,T) >= 1. n_total = size of the whole indexed window (the padded tree size, a constant of
        the context window, identical in training and decoding). It carries no token content, so using it is causal."""
        c = self.cfg
        if self.thr_init.item() == 0:
            return torch.ones_like(s)
        u = s / self.thr.clamp(min=1e-3) - 1.0
        e = ((F.softplus(c.spike_soft * u) - math.log1p(math.exp(-c.spike_soft))) / c.spike_soft).clamp(max=c.spike_cap)
        if c.spike_scale == 'sqrt_n':
            scale = math.sqrt(max(int(n_total), 1))
        elif c.spike_scale == 'levels':                                   # number of levels of the (padded) tree: log2 N
            scale = math.log2(max(int(n_total), 2))
        else:
            scale = float(c.content_dim)
        return 1.0 + c.spike_amp * scale * e

    def flag_frac(self, s):
        if self.thr_init.item() == 0 or s.shape[1] <= self.cfg.spike_min_hist:
            return torch.zeros((), device=s.device)
        return (s[:, self.cfg.spike_min_hist:] > self.thr).float().mean().detach()

    # ------------------------------------------------------------------ early tokens (positions 1 .. spike_min_hist-1)
    @torch.no_grad()
    def early_stats(self, xe):
        """xe (b,m-1,C): the layer inputs at positions 1..m-1 (m = spike_min_hist). Leave-one-out mean/std of the other
        m-2 tokens, per token. Returns (mu, sd) each (b,m-1,C)."""
        n = xe.shape[1]
        xd = xe.detach().double()
        sm, sm2 = xd.sum(1, keepdim=True), (xd * xd).sum(1, keepdim=True)
        k = max(n - 1, 1)
        mu = (sm - xd) / k
        var = ((sm2 - xd * xd) / k - mu * mu).clamp(min=0)
        return mu.float(), (var + EPS_VAR).sqrt().float()

    def early_scores(self, xe):
        """Retroactive score of tokens 1..m-1, computed once position m-1 has been seen (all tokens < m). Same score as
        scores() (local z-score times the global gate; for these tokens window == global history), leave-one-out so the
        token does not damp its own z-score. Gradient flows through the token itself only."""
        mu, sd = self.early_stats(xe)
        s_loc = _rms((xe.float() - mu) / sd)
        if self.cfg.spike_gate and self.thr_init.item() != 0:
            gate = torch.sigmoid(self.cfg.gate_sharp * (s_loc.detach() / self.gthr.clamp(min=1e-3) - 1.0))
        else:
            gate = torch.ones_like(s_loc)
        return torch.nan_to_num(s_loc * gate, nan=0.0, posinf=1e3).clamp(max=1e3)
