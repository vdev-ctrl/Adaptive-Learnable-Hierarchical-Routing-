import numpy as np
import torch


@torch.no_grad()
def needle_accuracy(model, task, T, depths=(0.0, 0.25, 0.5, 0.75, 1.0), n=32, n_needles=4, bs=2, amp=True):
    """Teacher-forced exact recall of the three value tokens, one question per sequence.
    Returns {depth: (acc_first_token, acc_all_three, keys_read, needle_hit_per_layer)}.
    needle_hit = share of sequences in which the needle's value position was among the keys that layer read."""
    model.eval()
    dev = next(model.parameters()).device
    out = {}
    for d in depths:
        first = full = keys = cnt = 0.0
        hits = None
        for _ in range(0, n, bs):
            idx, y, route, ans = task.sample(bs, T, n_needles=n_needles, depth=d)
            with torch.autocast(dev.type, dtype=torch.float16, enabled=amp and dev.type == 'cuda'):
                logits, _, st = model(idx.to(dev), route=tuple(r.to(dev) for r in route))
            pred = logits[:, -3:].argmax(-1).cpu()
            first += (pred[:, 0] == ans[:, 0]).float().sum().item()
            full += (pred == ans).all(1).float().sum().item()
            keys += st.get('keys', 0.0) * bs
            h = np.array(st.get('hit', []))
            hits = h * bs if hits is None else hits + h * bs
            cnt += bs
        out[d] = (first / cnt, full / cnt, keys / cnt, (hits / cnt).tolist() if hits is not None else [])
    return out


def fmt_row(r):
    """one line: recall (first token / all three) per depth, keys read, needle-hit per layer averaged over depths."""
    rec = ' '.join('d%.2f:%.2f/%.2f' % (d, v[0], v[1]) for d, v in r.items())
    keys = np.mean([v[2] for v in r.values()])
    hit = np.mean([v[3] for v in r.values()], axis=0)
    return '%s | avg first %.2f all3 %.2f | keys %.1f | hit/layer %s' % (
        rec, np.mean([v[0] for v in r.values()]), np.mean([v[1] for v in r.values()]), keys, ' '.join('%.2f' % h for h in hit))


@torch.no_grad()
def mqar_accuracy(model, task, T, n_kv, n=32, bs=2, amp=True):
    """Accuracy over all answer positions. Returns (accuracy, keys_read, needle_hit_per_layer)."""
    model.eval()
    dev = next(model.parameters()).device
    corr = tot = keys = cnt = 0.0
    hits = None
    for _ in range(0, n, bs):
        idx, y, route = task.sample(bs, T, n_kv)
        with torch.autocast(dev.type, dtype=torch.float16, enabled=amp and dev.type == 'cuda'):
            logits, _, st = model(idx.to(dev), route=tuple(r.to(dev) for r in route))
        m = y != -100
        pred = logits.argmax(-1).cpu()
        corr += ((pred == y) & m).sum().item()
        tot += m.sum().item()
        keys += st.get('keys', 0.0) * bs
        h = np.array(st.get('hit', []))
        hits = h * bs if hits is None else hits + h * bs
        cnt += bs
    return corr / tot, keys / cnt, (hits / cnt).tolist()
