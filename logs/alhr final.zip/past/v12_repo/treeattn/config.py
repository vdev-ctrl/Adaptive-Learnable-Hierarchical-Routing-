from dataclasses import dataclass, asdict


@dataclass
class Config:
    # ---- model
    vocab_size: int = 8192
    seq_len: int = 1024            # only used for the optional absolute position table and defaults
    n_layer: int = 4
    n_head: int = 4
    n_embd: int = 256
    rot_dims: int = 16             # head dims that carry rotary position (exact attention only, NOT indexed by the tree)
    rope_base: float = 10000.0
    rope_cap: int = 0              # 0 = off. > 0: exact attention sees every key at relative distance <= rope_cap (RoPE extrapolation probe)
    abs_pos: bool = False          # learned absolute positions instead of rotary (cannot extrapolate past seq_len)

    # ---- tree search
    wmax: int = 16                 # beam width: max tree nodes kept per level
    local: int = 3                 # static recent keys: t, t-1, t-2 (the sink at position 0 is always added too)
    max_keys: int = 40             # hard cap on keys read per query (priority: static > tree > neighbours)
    q_chunk: int = 1024            # queries processed at once (bounds memory, any sequence length)

    node_norm: str = 'mean'        # node score = q.S / n ('mean'), q.S / sqrt(n) ('sqrt': divides by sqrt of node size), or q.S ('none')

    # ---- budget predictor (trainable function 2)
    budget_mode: str = 'pred'      # 'pred' or 'fixed'
    fixed_budget: int = 4          # leaf groups (2 keys each) when budget_mode == 'fixed'
    beam_classes: tuple = (2, 3, 4, 6, 8)
    pred_hidden: int = 64
    pred_weight: float = 0.1

    # ---- neighbour search
    neighbors: bool = True
    nb_window: int = 8             # how many earlier queries a query may borrow from
    nb_store: int = 2              # best tree leaves each query stores for its neighbours
    nb_level: int = 1              # 1 = groups of 2 keys, 2 = groups of 4 keys, ...
    nb_rho: float = 0.35           # a borrowed group matches if new score >= old score - rho * |old score|
    nb_probe: int = 3              # nearest queries used to estimate the match rate (sets the variable cap)
    nb_cap_min: int = 2

    # ---- spike detector (on the tokens, before the splitter) + amplification
    spike: bool = True
    spike_win: int = 64            # trailing window of previous tokens (local gradient)
    spike_min_hist: int = 16
    spike_gate: bool = True        # loose global range from the running global sum / sum of squares
    spike_gq: float = 0.5          # glb_thr = this running quantile of the global z-score (loose: the median)
    gate_sharp: float = 4.0
    spike_q: float = 0.95          # thr = running quantile of the (gated) local score; frozen at inference
    spike_ema: float = 0.99
    spike_scale: str = 'd'         # 'levels': multiplier ~ number of tree levels log2(N) | 'd': ~ content dims | 'sqrt_n': ~ sqrt(N)
    spike_amp: float = 1.0         # mult = 1 + amp * scale * e   (sqrt_n equals the 'd' version when amp = d / sqrt(N_train): 0.75 at N = 4096, d = 48)
    spike_early: bool = True       # retroactively score the first spike_min_hist tokens once they have been seen (causal, see attention.py)
    spike_cap: float = 4.0
    spike_soft: float = 4.0        # softplus sharpness (smooth, so below-threshold tokens still get gradient)

    # ---- routing loss (teaches the splitter to make important keys findable; needs `route` targets)
    route_weight: float = 0.1
    route_neg: int = 16
    route_min_layer: int = 1

    tree_off: bool = False         # inference ablation: no tree leaves are read (static + neighbour keys only)

    def to_dict(self):
        return asdict(self)

    @property
    def head_dim(self):
        return self.n_embd // self.n_head

    @property
    def content_dim(self):
        return self.head_dim - self.rot_dims
