"""Data helpers shared by the tree LM script and the external baselines (identical batches and validation windows), plus the
loader for routing labels that an EXTERNAL dense model extracted beforehand (the repo itself contains no dense attention)."""
import json
import os

import numpy as np
import torch

PAD = 65535                                   # marks an unused label row

EDGES = [0, 128, 256, 512, 1024, 2048, 4096, 8192, 16384, 32768]


def train_batch(data, b, T, step, seed, dev):
    """The batch for a given global step is a pure function of (seed, step): every model sees the same data in the same order."""
    rng = np.random.default_rng(seed * 1_000_003 + step)
    ix = rng.integers(0, len(data) - T - 1, size=b)
    x = np.stack([data[i:i + T] for i in ix]).astype(np.int64)
    y = np.stack([data[i + 1:i + 1 + T] for i in ix]).astype(np.int64)
    return torch.from_numpy(x).to(dev), torch.from_numpy(y).to(dev)


def val_windows(val, eot, T, n, seed=123, cross=False):
    """n deterministic window starts. cross=False: the T+1 tokens contain no end-of-document token (windows never cross a book).
    cross=True (Wikipedia: articles are short, windows span several): any start is allowed."""
    eots = np.array([], dtype=np.int64) if cross else np.flatnonzero(np.asarray(val) == eot)
    rng = np.random.default_rng(seed + T)
    starts, tries = [], 0
    while len(starts) < n and tries < 200000:
        tries += 1
        s = int(rng.integers(0, len(val) - T - 1))
        j = int(np.searchsorted(eots, s))
        if j < len(eots) and eots[j] <= s + T:
            continue
        starts.append(s)
    return starts


def window(val, s, T, dev):
    x = torch.from_numpy(np.asarray(val[s:s + T]).astype(np.int64))[None].to(dev)
    y = torch.from_numpy(np.asarray(val[s + 1:s + 1 + T]).astype(np.int64))[None].to(dev)
    return x, y


def bucket_line(ce, acc, T, train_len):
    """ce, acc: 1-D tensors, mean loss / next-token top-1 accuracy per position over the windows.
    Prints loss/accuracy per position bucket, the overall numbers (with perplexity) and the share beyond the trained length."""
    ce, acc = ce.cpu(), acc.cpu()
    parts = ['[%d,%d):%.3f/%.3f' % (lo, min(hi, T), ce[lo:hi].mean(), acc[lo:hi].mean()) for lo, hi in zip(EDGES, EDGES[1:]) if lo < T]
    far = ' | beyond train len %d: %.3f/%.3f' % (train_len, ce[train_len:].mean(), acc[train_len:].mean()) if T > train_len else ''
    return '(loss/acc) ' + ' '.join(parts) + ' | all %.3f/%.3f ppl %.0f' % (ce.mean(), acc.mean(), float(ce.mean().exp())) + far


# ---------------------------------------------------------------------------------------------------- routing labels
def load_labels(labels_dir):
    """labels_q / labels_t: uint16 memmaps (n_windows, n_layer, rows). Window i covers train tokens [i*T, i*T + T]. Row r of layer l
    says: the query at position q needs the key at position t (found by the external dense model); PAD = unused row."""
    meta = json.load(open(os.path.join(labels_dir, 'labels_meta.json')))
    shape = (meta['n_windows'], meta['n_layer'], meta['rows'])
    q = np.memmap(os.path.join(labels_dir, 'labels_q.u16'), dtype=np.uint16, mode='r', shape=shape)
    t = np.memmap(os.path.join(labels_dir, 'labels_t.u16'), dtype=np.uint16, mode='r', shape=shape)
    return meta, q, t


def window_order(n_windows, b, step, seed):
    """Window numbers of the batch at `step`: one shuffled pass over all labelled windows per epoch."""
    per_epoch = max(n_windows // b, 1)
    epoch, k = divmod(step, per_epoch)
    perm = np.random.default_rng(seed * 1_000_003 + epoch).permutation(n_windows)
    return perm[k * b:(k + 1) * b]


def labeled_batch(data, T, win_idx, q, t, dev):
    """(x, y, routes). routes is a per-layer list of (bidx, qpos, tgt) long tensors, None where a layer has no label this batch."""
    x = np.stack([data[i * T:i * T + T] for i in win_idx]).astype(np.int64)
    y = np.stack([data[i * T + 1:i * T + 1 + T] for i in win_idx]).astype(np.int64)
    qb = torch.from_numpy(np.asarray(q[np.sort(win_idx)]).astype(np.int64))
    tb = torch.from_numpy(np.asarray(t[np.sort(win_idx)]).astype(np.int64))
    order = np.argsort(np.argsort(win_idx))                    # memmap fancy indexing needs sorted rows; restore the batch order
    qb, tb = qb[order], tb[order]
    b = len(win_idx)
    routes = []
    for l in range(qb.shape[1]):
        ql, tl = qb[:, l], tb[:, l]
        ok = ql != PAD
        if not ok.any():
            routes.append(None)
            continue
        bi = torch.arange(b)[:, None].expand_as(ql)[ok]
        routes.append((bi.to(dev), ql[ok].to(dev), tl[ok].to(dev)))
    return torch.from_numpy(x).to(dev), torch.from_numpy(y).to(dev), routes
