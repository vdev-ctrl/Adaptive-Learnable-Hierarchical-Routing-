"""Train the tree model on MQAR (Zoology-style multi-query associative recall), from scratch, optionally in STAGES of
growing context length.

Why stages: cost per step is roughly proportional to tokens per batch (not to T), so a long window is cheap per step but
gives few graded answers per step (16 per sequence). Training from scratch at 4096 would therefore be slow to start.
Instead the recall circuit forms at a short window (fast: a few thousand steps at 256), then the same weights are
trained at 1024 and 4096 so that gaps beyond 256 are seen in training. Every stage is purely tree attention.

  python scripts/train_mqar.py --out runs/s0 --seed 0 --stages 256:16:1500,1024:16:1500,4096:16:2500 \\
      --spike_scale sqrt_n --spike_amp 0.75
  stage spec = T:n_kv:steps. Without --stages a single stage (--T, --n_kv, --steps) is run.
The run resumes from out/ckpt.pt (stage and step are stored), so a dead Kaggle session can simply be restarted.
"""
import argparse
import math
import os
import sys
import time

import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from treeattn import Config, TreeGPT
from treeattn.evaluate import mqar_accuracy
from treeattn.tasks import MQARTask

p = argparse.ArgumentParser()
p.add_argument('--out', default='runs/mqar')
p.add_argument('--T', type=int, default=256)
p.add_argument('--n_kv', type=int, default=16)
p.add_argument('--steps', type=int, default=20000)
p.add_argument('--stages', default='', help='T:n_kv:steps,... (curriculum over context length); overrides --T/--n_kv/--steps')
p.add_argument('--stage_lr_decay', type=float, default=0.5, help='peak lr of each later stage = previous * this')
p.add_argument('--stage_warmup', type=int, default=100)
p.add_argument('--tokens_per_batch', type=int, default=16384)
p.add_argument('--lr', type=float, default=1e-3)
p.add_argument('--warmup', type=int, default=300)
p.add_argument('--vocab', type=int, default=8192)
p.add_argument('--n_layer', type=int, default=4)
p.add_argument('--n_head', type=int, default=4)
p.add_argument('--n_embd', type=int, default=256)
p.add_argument('--wmax', type=int, default=16)
p.add_argument('--beam_classes', default='2,3,4,6,8')
p.add_argument('--max_keys', type=int, default=40)
p.add_argument('--q_chunk', type=int, default=1024)
p.add_argument('--route_weight', type=float, default=0.3)
p.add_argument('--node_norm', default='mean', choices=['mean', 'sqrt', 'none'])
p.add_argument('--spike', type=int, default=1)
p.add_argument('--spike_scale', default='d', choices=['d', 'sqrt_n', 'levels'])
p.add_argument('--spike_amp', type=float, default=1.0)
p.add_argument('--spike_q', type=float, default=0.95)
p.add_argument('--spike_gate', type=int, default=1)
p.add_argument('--rope_cap', type=int, default=0, help='max relative distance exact attention sees; 0 = auto = the longest training T (diagnosed: without it, gaps beyond the trained range fail)')
p.add_argument('--spike_early', type=int, default=1, help='retroactively score the first spike_min_hist tokens (causal)')
p.add_argument('--eval_every', type=int, default=1000)
p.add_argument('--eval_n', type=int, default=32)
p.add_argument('--eval_grid', default='256:16,1024:16,4096:16,16384:16')
p.add_argument('--log_every', type=int, default=200)
p.add_argument('--resume', type=int, default=1, help='continue from out/ckpt.pt if it exists (Kaggle sessions die)')
p.add_argument('--seed', type=int, default=0)
a = p.parse_args()

stages = [tuple(int(v) for v in sp.split(':')) for sp in a.stages.split(',')] if a.stages else [(a.T, a.n_kv, a.steps)]
torch.manual_seed(a.seed)
dev = 'cuda' if torch.cuda.is_available() else 'cpu'
task = MQARTask(vocab_size=a.vocab, seed=a.seed)
cfg = Config(vocab_size=a.vocab, n_layer=a.n_layer, n_head=a.n_head, n_embd=a.n_embd, wmax=a.wmax, beam_classes=tuple(int(v) for v in a.beam_classes.split(',')), max_keys=a.max_keys, q_chunk=a.q_chunk,
             route_weight=a.route_weight,
             node_norm=a.node_norm, spike=bool(a.spike), spike_scale=a.spike_scale, spike_amp=a.spike_amp, spike_q=a.spike_q,
             spike_gate=bool(a.spike_gate), spike_early=bool(a.spike_early),
             rope_cap=a.rope_cap or max(st_[0] for st_ in stages))
model = TreeGPT(cfg).to(dev)
print('device', dev, '| params %.2fM | stages %s | seed %d | node_norm %s | spike %s scale %s amp %.2f q %.2f gate %s early %s | rope_cap %d' % (
    sum(q.numel() for q in model.parameters()) / 1e6, stages, a.seed, a.node_norm, bool(a.spike), a.spike_scale, a.spike_amp,
    a.spike_q, bool(a.spike_gate), bool(a.spike_early), cfg.rope_cap), flush=True)
opt = torch.optim.AdamW(model.parameters(), lr=a.lr, betas=(0.9, 0.95), weight_decay=0.01)
use_amp = dev == 'cuda'
scaler = torch.amp.GradScaler('cuda', enabled=use_amp)
os.makedirs(a.out, exist_ok=True)
ckpt_path = os.path.join(a.out, 'ckpt.pt')
start_stage, start_k, step, skipped = 0, 0, 0, 0
if a.resume and os.path.exists(ckpt_path):
    ck = torch.load(ckpt_path, map_location=dev, weights_only=False)
    model.load_state_dict(ck['model'])
    opt.load_state_dict(ck['opt'])
    step, start_stage, start_k = ck['step'], ck.get('stage', 0), ck.get('stage_step', 0)
    print('resumed: global step %d, stage %d, step %d inside it' % (step, start_stage, start_k), flush=True)


def save(si, k):
    torch.save({'cfg': cfg.to_dict(), 'model': model.state_dict(), 'opt': opt.state_dict(), 'step': step, 'stage': si,
                'stage_step': k, 'stages': stages, 'seed': a.seed, 'vocab': a.vocab}, ckpt_path)


ema, t_start, n_timed = None, time.time(), 0
for si in range(start_stage, len(stages)):
    T, n_kv, n_steps = stages[si]
    peak = a.lr * a.stage_lr_decay ** si
    b = max(1, a.tokens_per_batch // T)
    k0 = start_k if si == start_stage else 0
    print('  >>> STAGE %d/%d: T=%d n_kv=%d steps=%d batch=%d seqs (%d graded answers) peak lr %.1e from step %d' % (
        si + 1, len(stages), T, n_kv, n_steps, b, b * n_kv, peak, k0), flush=True)
    for k in range(k0, n_steps):
        warm = a.warmup if si == 0 else a.stage_warmup
        for g in opt.param_groups:
            g['lr'] = peak * min(1.0, (k + 1) / warm) * (0.1 + 0.9 * 0.5 * (1 + math.cos(math.pi * k / n_steps)))
        model.train()
        idx, y, route = task.sample(b, T, n_kv)
        idx, y, route = idx.to(dev), y.to(dev), tuple(r.to(dev) for r in route)
        with torch.autocast(dev, dtype=torch.float16, enabled=use_amp):
            _, loss, st = model(idx, y, route)
        if not torch.isfinite(loss):
            skipped += 1
            step += 1
            if skipped > 100:
                raise SystemExit('too many non-finite steps')
            continue
        ema = st['lm'] if ema is None else 0.98 * ema + 0.02 * st['lm']
        opt.zero_grad(set_to_none=True)
        scaler.scale(loss).backward()
        scaler.unscale_(opt)
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        scaler.step(opt)
        scaler.update()
        step += 1
        n_timed += 1
        done = k + 1
        if done % a.log_every == 0 or step == 1:
            print('step %d (stage %d: %d/%d) | lm %.3f (ema %.3f) route %.3f pred %.3f | keys %.1f flagged %.3f | hit/layer %s | lr %.1e | %.2fs/step' % (
                step, si + 1, done, n_steps, st['lm'], ema, st['route'], st['pred'], st.get('keys', 0), st.get('flag_frac', 0),
                ' '.join('%.2f' % h for h in st.get('hit', [])), opt.param_groups[0]['lr'], (time.time() - t_start) / max(1, n_timed)), flush=True)
            if 'chist' in st and (done % (a.log_every * 4) == 0 or step == 1):
                print('    budget classes %s, share of queries per class per layer: %s' % (a.beam_classes, ' '.join('[' + ','.join('%.2f' % v for v in h) + ']' for h in st['chist'])), flush=True)
        if done % a.eval_every == 0 or done == n_steps:
            acc, keys, hit = mqar_accuracy(model, task, T, n_kv, n=a.eval_n, bs=2 if T <= 4096 else 1, amp=use_amp)
            print('  EVAL step %d | T=%d n_kv=%d | ACC %.3f | keys %.1f | hit/layer %s' % (
                step, T, n_kv, acc, keys, ' '.join('%.2f' % h for h in hit)), flush=True)
            if done < n_steps:
                save(si, done)
            else:
                save(si + 1, 0)                      # stage finished: resume at the start of the next one

print('\n=== FINAL MQAR accuracy seed %d (chance ~ 1/%d). Same weights, longer sequences, thresholds frozen.' % (a.seed, a.vocab // 2))
for gspec in a.eval_grid.split(','):
    T, nkv = (int(v) for v in gspec.split(':'))
    acc, keys, hit = mqar_accuracy(model, task, T, nkv, n=a.eval_n, bs=1 if T > 4096 else 2, amp=use_amp)
    print('T=%6d n_kv=%3d | acc %.3f | keys %.1f | hit/layer %s' % (T, nkv, acc, keys, ' '.join('%.2f' % h for h in hit)), flush=True)
