"""Evaluate a needle checkpoint on longer lengths. --no_spike switches amplification off at inference (ablation)."""
import argparse
import os
import sys

import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from treeattn import Config, TreeGPT
from treeattn.evaluate import fmt_row, needle_accuracy
from treeattn.tasks import NeedleTask

p = argparse.ArgumentParser()
p.add_argument('--ckpt', required=True)
p.add_argument('--lengths', default='1024,4096,16384,65536')
p.add_argument('--n', type=int, default=24)
p.add_argument('--n_needles', type=int, default=4)
p.add_argument('--no_spike', action='store_true')
p.add_argument('--seed', type=int, default=123)
a = p.parse_args()
dev = 'cuda' if torch.cuda.is_available() else 'cpu'
ck = torch.load(a.ckpt, map_location=dev, weights_only=False)
cfg = Config(**ck['cfg'])
if a.no_spike:
    cfg.spike = False
model = TreeGPT(cfg).to(dev)
model.load_state_dict(ck['model'])
task = NeedleTask(seed=a.seed, **ck['task'])
print('spike amplification:', cfg.spike)
for T in [int(v) for v in a.lengths.split(',')]:
    r = needle_accuracy(model, task, T, n=a.n, n_needles=a.n_needles, bs=1 if T > 16384 else 2, amp=dev == 'cuda')
    print('T=%6d | %s' % (T, fmt_row(r)), flush=True)
