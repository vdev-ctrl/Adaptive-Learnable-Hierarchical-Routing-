"""Diagnostics for a trained tree model on MQAR. Inference only, nothing is trained.

For every length in --T_list it answers, per layer:
  1. WHO fails: accuracy by pair index (pairs whose value sits in the first spike_min_hist positions are blind to the
     spike detector), by query-to-value gap, and given whether the tree beam reached the needle.
  2. SPIKE: flagged fraction, needle recall / precision, needle score percentile, multiplier on needles vs others.
  3. BEAM: does the needle's leaf survive the descent (tree only, full beam)? At which tree level does it drop out, and
     how far outside the beam was it (rank)? Hit rate for beam 1x / 2x / 4x.
  4. BUDGET PREDICTOR: histogram of predicted leaf budgets at the query rows, mean norm of the global vector.
Then an inference-only ablation table (same data for every variant): wider beam, bigger budget, no neighbours, no spike,
thresholds recalibrated at this length, ORACLE spike (true needles forced to the maximum multiplier), node_norm sqrt.
Variants that change something the model was not trained with are upper-bound probes, not fixes.

  python scripts/diagnose_mqar.py --ckpt runs/mqar_sqrtn/ckpt.pt
"""
import argparse
import math
import os
import sys
import time

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from treeattn import Config, TreeGPT
from treeattn.attention import rotary
from treeattn.tasks import MQARTask
from treeattn.tree import build_levels, gather_nodes, next_pow2, node_scale


# ---------------------------------------------------------------------------------------------- layer internals
@torch.no_grad()
def layer_internals(attn, x):
    """Recompute what one attention layer indexes, from its input x (b,T,C): content queries, tree levels S, global vector
    G, spike score s and multiplier. Same operations as TreeAttention.forward (parallel path)."""
    cfg = attn.cfg
    b, T, C = x.shape
    H, dh, rot = attn.H, attn.dh, attn.rot
    tq = torch.arange(T, device=x.device)
    q, k, _ = [t.view(b, T, H, dh).transpose(1, 2) for t in attn.qkv(x).split(C, 2)]
    q, k = rotary(q, tq, rot, cfg.rope_base), rotary(k, tq, rot, cfg.rope_base)
    if cfg.spike:
        s, _ = attn.spike.scores(x, attn.spike.stats_parallel(x))
        mult = attn.spike.multiplier(s, next_pow2(T))
    else:
        s, mult = torch.zeros(b, T, device=x.device), torch.ones(b, T, device=x.device)
    kidx = torch.nan_to_num(k[..., rot:].float() * mult.unsqueeze(1).unsqueeze(-1), nan=0.0, posinf=1e4, neginf=-1e4)
    kidx = kidx * (tq != 0).view(1, 1, T, 1).to(kidx.dtype)
    S = build_levels(kidx, next_pow2(T))
    return dict(qc=q[..., rot:].float(), S=S, G=kidx.cumsum(2) - kidx, s=s, mult=mult)


@torch.no_grad()
def traced_descent(q, S, tq, tgt, wmax, norm):
    """tree_descent that also records, per level, whether the needle's ancestor survived the beam.
    q (1,H,N,d); S levels for the same sequence; tq, tgt (N,) query / needle positions.
    Returns {level: (kept (H,N) bool, valid (N,) bool, rank (H,N) long)}; rank = number of candidates that outscored
    the ancestor at that level (1e6 if it was not a candidate)."""
    b, H, N, _ = q.shape
    ids = vld = None
    out = {}
    for l in range(len(S) - 1, 0, -1):
        bit = ((tq >> l) & 1) == 1
        inj = ((tq >> l) - 1).clamp(min=0).view(1, 1, N, 1).expand(b, H, N, 1)
        injv = bit.view(1, 1, N, 1).expand(b, H, N, 1)
        if ids is None:
            cand, cv = inj, injv
        else:
            cand = torch.cat([2 * ids, 2 * ids + 1, inj], -1)
            cv = torch.cat([vld, vld, injv], -1)
        sc = torch.einsum('bhnd,bhncd->bhnc', q, gather_nodes(S[l], cand)) / node_scale(l, norm)
        sc = sc.masked_fill(~cv, float('-inf'))
        a = (tgt >> l).view(1, 1, N, 1)
        a_ok = (((tgt >> l) + 1) << l) <= tq                       # ancestor lies completely in the past of the query
        is_a = (cand == a) & cv
        a_sc = sc.masked_fill(~is_a, float('-inf')).amax(-1, keepdim=True)
        rank = ((sc > a_sc) & cv).sum(-1)
        rank = torch.where(is_a.any(-1), rank, torch.full_like(rank, 10 ** 6))
        _, order = sc.topk(min(wmax, cand.shape[-1]), dim=-1)
        ids, vld = cand.gather(-1, order), cv.gather(-1, order)
        out[l] = (((ids == a) & vld).any(-1)[0], a_ok, rank[0])
    return out


def merge(recs):
    out = {}
    for l in recs[0]:
        out[l] = (torch.cat([r[l][0] for r in recs], 1).cpu(), torch.cat([r[l][1] for r in recs], 0).cpu(),
                  torch.cat([r[l][2] for r in recs], 1).cpu())
    return out


def summarize_descent(rec):
    """rec {level: (kept, valid, rank)} over all rows. Returns hit rate, per-row found flag, drop-level histogram, ranks."""
    levels = sorted(rec, reverse=True)
    H, N = rec[levels[0]][0].shape
    lost = torch.zeros(H, N, dtype=torch.long)
    rk = torch.zeros(H, N, dtype=torch.long)
    for l in levels:
        kept, valid, rank = rec[l]
        newly = (lost == 0) & valid.unsqueeze(0) & ~kept
        lost = torch.where(newly, torch.full_like(lost, l), lost)
        rk = torch.where(newly, rank, rk)
    valid1 = rec[1][1]
    found = (lost == 0).any(0) & valid1
    miss = valid1 & ~found
    drop, ranks = {}, []
    if miss.any():
        deep = lost[:, miss].argmin(0)                            # head that got deepest before losing the needle
        dl = lost[:, miss].gather(0, deep.unsqueeze(0))[0]
        ranks = rk[:, miss].gather(0, deep.unsqueeze(0))[0].tolist()
        for l in dl.tolist():
            drop[l] = drop.get(l, 0) + 1
    n = int(valid1.sum())
    return dict(hit=float(found.sum()) / max(n, 1), found=found, valid=valid1, n=n, drop=drop, ranks=ranks)


# ---------------------------------------------------------------------------------------------- accumulators
def add(acc, k, v):
    acc[k] = acc.get(k, 0.0) + float(v)


def spike_stats(acc, cfg, attn, it, bi, tg, T, bs):
    sp, s, mult = attn.spike, it['s'], it['mult']
    mh = cfg.spike_min_hist
    valid = (torch.arange(T, device=s.device) > mh).view(1, -1)
    flagged = (s > sp.thr) & valid
    needle = torch.zeros(bs, T, dtype=torch.bool, device=s.device)
    needle[bi, tg] = True
    vis, blind = needle & valid, needle & ~valid
    add(acc, 'flag', flagged.sum()), add(acc, 'valid', valid.sum() * bs)
    add(acc, 'n_nd', needle.sum()), add(acc, 'n_vis', vis.sum()), add(acc, 'n_blind', blind.sum())
    add(acc, 'flag_vis', (flagged & vis).sum()), add(acc, 'flag_nd', (flagged & needle).sum())
    add(acc, 'mult_nd', mult[needle].sum()), add(acc, 'mult_all', (mult * valid).sum()), add(acc, 'mult_n', valid.sum() * bs)
    for j in range(bs):
        nd = s[j][vis[j]]
        if nd.numel():
            acc.setdefault('pct', []).extend((s[j][valid[0]].view(1, -1) < nd.view(-1, 1)).float().mean(1).tolist())


def budget_stats(acc, attn, it, bi, qp):
    qr = it['qc'][bi, :, qp].permute(1, 0, 2).unsqueeze(0)
    Gr = it['G'][bi, :, qp].permute(1, 0, 2).unsqueeze(0)
    lhat, _ = attn._budget(qr, Gr)
    for c in attn.classes.tolist():
        add(acc, 'c%d' % c, (lhat == c).sum())
    add(acc, 'n', lhat.numel()), add(acc, 'gnorm', Gr.norm(dim=-1).sum()), add(acc, 'gcnt', Gr.shape[1] * Gr.shape[2])
    add(acc, 'qnorm', qr.norm(dim=-1).sum())


# ---------------------------------------------------------------------------------------------- per-length diagnosis
@torch.no_grad()
def diag_T(model, cfg, vocab, T, n_kv, n, bs, seed, amp, dev):
    task = MQARTask(vocab, seed=seed)
    L = len(model.blocks)
    widths = [cfg.wmax, 2 * cfg.wmax, 4 * cfg.wmax]
    corr, tgts, gaps, mhit = [], [], [], []
    recs = [[[] for _ in widths] for _ in range(L)]
    spk, bud = [{} for _ in range(L)], [{} for _ in range(L)]
    t0 = time.time()
    for _ in range(0, n, bs):
        idx, y, route = task.sample(bs, T, n_kv)
        idx, y = idx.to(dev), y.to(dev)
        bi, qp, tg = (r.to(dev) for r in route)
        caps = {}

        def mk(i):
            def hook(m, args):
                caps[i] = args[0].detach()
            return hook
        hooks = [blk.attn.register_forward_pre_hook(mk(i)) for i, blk in enumerate(model.blocks)]
        with torch.autocast(dev.type, dtype=torch.float16, enabled=amp):
            logits, _, st = model(idx, route=(bi, qp, tg))
        for h in hooks:
            h.remove()
        mhit.append(st.get('hit', []))
        corr.append((logits[bi, qp].argmax(-1) == y[bi, qp]).cpu())
        tgts.append(tg.cpu()), gaps.append((qp - tg).cpu())
        for i, blk in enumerate(model.blocks):
            attn = blk.attn
            with torch.autocast(dev.type, dtype=torch.float16, enabled=amp):
                it = layer_internals(attn, caps[i])
                if cfg.spike:
                    spike_stats(spk[i], cfg, attn, it, bi, tg, T, bs)
                if cfg.budget_mode == 'pred':
                    budget_stats(bud[i], attn, it, bi, qp)
            for wi, w in enumerate(widths):
                per = []
                for j in range(bs):
                    m = bi == j
                    qpj, tgj = qp[m], tg[m]
                    Sj = [None] + [s_[j:j + 1] for s_ in it['S'][1:]]
                    per.append(traced_descent(it['qc'][j:j + 1][:, :, qpj], Sj, qpj, tgj, w, cfg.node_norm))
                recs[i][wi].append(merge(per))
        del caps, it
    corr, tgts, gaps = torch.cat(corr), torch.cat(tgts), torch.cat(gaps)
    summ = [[summarize_descent(merge_batches(recs[i][wi])) for wi in range(len(widths))] for i in range(L)]
    print('\n' + '=' * 110)
    print('T=%d n_kv=%d | %d sequences, %d answers | %.0fs | levels in tree: %d' % (T, n_kv, n, len(corr), time.time() - t0,
          int(math.log2(next_pow2(T))) - 1))
    print('=' * 110)
    print('accuracy %.3f | model read-set hit/layer %s' % (corr.float().mean(), ' '.join('%.2f' % h for h in np.mean(mhit, 0))))

    mh = cfg.spike_min_hist
    blind = tgts <= mh
    print('\n[1] WHO FAILS')
    print('  pairs whose value is at position <= %d (spike-blind): acc %.3f (n=%d) | later pairs: acc %.3f (n=%d)' % (
        mh, corr[blind].float().mean() if blind.any() else float('nan'), int(blind.sum()),
        corr[~blind].float().mean() if (~blind).any() else float('nan'), int((~blind).sum())))
    edges = [0, 256, 1024, 4096, 16384, 10 ** 9]
    parts = []
    for a_, b_ in zip(edges[:-1], edges[1:]):
        m = (gaps >= a_) & (gaps < b_)
        if m.any():
            parts.append('gap %d-%s: %.3f (n=%d)' % (a_, '' if b_ >= 10 ** 9 else b_, corr[m].float().mean(), int(m.sum())))
    print('  ' + ' | '.join(parts))
    found_any = torch.zeros_like(corr)
    for i in range(1, L):
        found_any |= summ[i][0]['found']
    if found_any.any() and (~found_any).any():
        print('  tree beam reached the needle in some routed layer: acc %.3f (n=%d) | in none: acc %.3f (n=%d)' % (
            corr[found_any].float().mean(), int(found_any.sum()), corr[~found_any].float().mean(), int((~found_any).sum())))
    else:
        print('  beam reached the needle in some routed layer for %d of %d rows' % (int(found_any.sum()), len(corr)))

    if cfg.spike:
        print('\n[2] SPIKE (needle = the value token of each pair; thr is frozen from training)')
        for i in range(L):
            a = spk[i]
            pct = np.array(a.get('pct', [np.nan]))
            print('  L%d thr %.2f | flagged %.1f%% | needle recall: visible %.2f blind %d/%d never scored | precision %.3f | '
                  'needle score percentile median %.2f | mult needle %.1f vs avg %.1f' % (
                      i, float(model.blocks[i].attn.spike.thr), 100 * a['flag'] / a['valid'],
                      a['flag_vis'] / max(a['n_vis'], 1), a['n_blind'], a['n_nd'], a['flag_nd'] / max(a['flag'], 1),
                      np.nanmedian(pct), a['mult_nd'] / a['n_nd'], a['mult_all'] / a['mult_n']))

    print('\n[3] BEAM (tree only, full beam, no budget cut). hit = needle leaf survives the descent in at least one head')
    for i in range(L):
        h = ' '.join('%dx(w=%d): %.2f' % (m_, w, summ[i][k]['hit']) for k, (m_, w) in enumerate(zip((1, 2, 4), widths)))
        s0 = summ[i][0]
        line = '  L%d hit %s | rows %d' % (i, h, s0['n'])
        if s0['drop']:
            tot = sum(s0['drop'].values())
            line += ' | drop-out level (share of misses): ' + ' '.join('L%d:%.2f' % (l, c / tot) for l, c in sorted(s0['drop'].items(), reverse=True))
            r = np.array(s0['ranks'])
            line += ' | rank at drop: median %d, <2w %.2f, <4w %.2f' % (np.median(r), (r < 2 * widths[0]).mean(), (r < 4 * widths[0]).mean())
        print(line + ('  (layer 0 has no routing loss)' if i == 0 else ''))

    if cfg.budget_mode == 'pred':
        print('\n[4] BUDGET PREDICTOR (leaf groups of 2 keys predicted at the query rows)')
        for i in range(L):
            a = bud[i]
            cl = ' '.join('%s:%.2f' % (c, a[c] / a['n']) for c in sorted((k for k in a if k[0] == 'c'), key=lambda z: int(z[1:])))
            print('  L%d classes %s | mean |G| %.1f | mean |q| %.2f' % (i, cl, a['gnorm'] / a['gcnt'], a['qnorm'] / a['gcnt']))
    sys.stdout.flush()


def merge_batches(lst):
    out = {}
    for l in lst[0]:
        out[l] = (torch.cat([r[l][0] for r in lst], 1), torch.cat([r[l][1] for r in lst], 0), torch.cat([r[l][2] for r in lst], 1))
    return out


# ---------------------------------------------------------------------------------------------- ablations
class Override:
    def __init__(self, cfg, kw):
        self.cfg, self.kw = cfg, kw

    def __enter__(self):
        self.old = {k: getattr(self.cfg, k) for k in self.kw}
        for k, v in self.kw.items():
            setattr(self.cfg, k, v)

    def __exit__(self, *a):
        for k, v in self.old.items():
            setattr(self.cfg, k, v)


@torch.no_grad()
def evaluate(model, vocab, T, n_kv, n, bs, seed, amp, dev, state=None):
    task = MQARTask(vocab, seed=seed)
    model.eval()
    corr = tot = cnt = 0
    hits = None
    for _ in range(0, n, bs):
        idx, y, route = task.sample(bs, T, n_kv)
        idx, route = idx.to(dev), tuple(r.to(dev) for r in route)
        if state is not None:
            m = torch.zeros(bs, T, dtype=torch.bool, device=dev)
            m[route[0], route[2]] = True
            state['mask'] = m
        with torch.autocast(dev.type, dtype=torch.float16, enabled=amp):
            logits, _, st = model(idx, route=route)
        pred, mk = logits.argmax(-1).cpu(), y != -100
        corr += ((pred == y) & mk).sum().item()
        tot += mk.sum().item()
        h = np.array(st.get('hit', []))
        hits = h * bs if hits is None else hits + h * bs
        cnt += bs
    return corr / tot, (hits / cnt).tolist()


@torch.no_grad()
def recalibrate(model, cfg, vocab, T, n_kv, seed, amp, dev):
    """Set every layer's spike thresholds from the score distribution at THIS length (one batch). Returns a restore fn."""
    idx, _, route = MQARTask(vocab, seed=seed + 999).sample(1, T, n_kv)
    caps = {}
    hooks = []
    for i, blk in enumerate(model.blocks):
        hooks.append(blk.attn.register_forward_pre_hook(lambda m, a, i=i: caps.__setitem__(i, a[0].detach())))
    with torch.autocast(dev.type, dtype=torch.float16, enabled=amp):
        model(idx.to(dev), route=tuple(r.to(dev) for r in route))
    for h in hooks:
        h.remove()
    old = []
    for i, blk in enumerate(model.blocks):
        sp = blk.attn.spike
        old.append((sp.thr.clone(), sp.gthr.clone()))
        s, sg = sp.scores(caps[i], sp.stats_parallel(caps[i]))
        s, sg = s[:, cfg.spike_min_hist + 1:].reshape(-1).float(), sg[:, cfg.spike_min_hist + 1:].reshape(-1).float()
        sp.thr.copy_(torch.quantile(s, cfg.spike_q).view(1))
        sp.gthr.copy_(torch.quantile(sg, cfg.spike_gq).view(1))

    def restore():
        for blk, (t, g) in zip(model.blocks, old):
            blk.attn.spike.thr.copy_(t)
            blk.attn.spike.gthr.copy_(g)
    return restore


def install_oracle(model, state):
    """Force the maximum multiplier on the true needle positions (state['mask'], set per batch)."""
    sps = [blk.attn.spike for blk in model.blocks]
    for sp in sps:
        def mk(orig):
            def f(s, pos):
                m = orig(s, pos)
                if state.get('mask') is None:
                    return m
                return torch.where(state['mask'][:, :s.shape[1]], orig(torch.full_like(s, 1e3), pos), m)
            return f
        sp.multiplier = mk(sp.multiplier)

    def remove():
        for sp in sps:
            del sp.multiplier
    return remove


VARIANTS = [
    ('base', {}),
    ('beam x2 (wmax 32)', dict(wmax=32)),
    ('beam x4 (wmax 64)', dict(wmax=64)),
    ('budget fixed 8 leaves', dict(budget_mode='fixed', fixed_budget=8)),
    ('beam 32 + budget 16 leaves + 80 keys', dict(wmax=32, budget_mode='fixed', fixed_budget=16, max_keys=80)),
    ('no neighbour search', dict(neighbors=False)),
    ('no spike', dict(spike=False)),
    ('spike thr recalibrated at this T', 'recal'),
    ('ORACLE spike on true needles', 'oracle'),
    ('node_norm sqrt (not trained)', dict(node_norm='sqrt')),
]


def run_ablations(model, cfg, a, dev, amp):
    Ts = [int(v) for v in a.abl_T.split(',')]
    print('\n' + '=' * 110)
    print('ABLATIONS (inference only, identical data per column, %d sequences each; +-%.0f%% sampling noise at 1 sigma)' % (
        a.n_abl, 100 * 0.5 / math.sqrt(a.n_abl * a.n_kv)))
    print('=' * 110)
    print('%-40s' % 'variant' + ''.join('| T=%-6d acc  hit(L1..)   ' % T for T in Ts))
    for name, kw in VARIANTS:
        row = '%-40s' % name
        for T in Ts:
            bs = 2 if T <= 1024 else 1
            restore = remove = None
            state = {'mask': None}
            if kw == 'oracle':
                remove = install_oracle(model, state)
            elif kw == 'recal':
                restore = recalibrate(model, cfg, a.vocab, T, a.n_kv, a.seed, amp, dev)
            try:
                with Override(cfg, kw if isinstance(kw, dict) else {}):
                    acc, hit = evaluate(model, a.vocab, T, a.n_kv, a.n_abl, bs, a.seed, amp, dev, state)
                row += '| %.3f  %-17s' % (acc, ' '.join('%.2f' % h for h in hit[1:]))
            except Exception as e:
                row += '| failed: %-22s' % str(e)[:22]
            finally:
                if restore:
                    restore()
                if remove:
                    remove()
        print(row, flush=True)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--ckpt', default='runs/mqar_sqrtn/ckpt.pt')
    p.add_argument('--T_list', default='256,1024,4096,16384')
    p.add_argument('--n_kv', type=int, default=16)
    p.add_argument('--n_diag', type=int, default=16)
    p.add_argument('--abl_T', default='1024,4096,16384')
    p.add_argument('--n_abl', type=int, default=16)
    p.add_argument('--skip_abl', type=int, default=0)
    p.add_argument('--seed', type=int, default=1234)
    a = p.parse_args()
    dev = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    amp = dev.type == 'cuda'
    ck = torch.load(a.ckpt, map_location=dev, weights_only=False)
    cfg = Config(**ck['cfg'])
    a.vocab = ck['vocab']
    model = TreeGPT(cfg).to(dev)
    model.load_state_dict(ck['model'])
    model.eval()
    print('loaded %s | step %s | vocab %d | node_norm %s spike %s scale %s | wmax %d budget %s' % (
        a.ckpt, ck.get('step'), a.vocab, cfg.node_norm, cfg.spike, cfg.spike_scale, cfg.wmax, cfg.budget_mode))
    for T in [int(v) for v in a.T_list.split(',')]:
        diag_T(model, cfg, a.vocab, T, a.n_kv, a.n_diag, 2 if T <= 1024 else 1, a.seed, amp, dev)
    if not a.skip_abl:
        run_ablations(model, cfg, a, dev, amp)


if __name__ == '__main__':
    main()
