"""Measured cost of ONE forward pass of the tree model (random weights, eval mode, batch 1) at growing lengths.
Prints seconds, microseconds per token and peak GPU memory. If attention were quadratic, us/token would grow ~linearly with T
(x4 per 4x length); for n log n it grows slowly. No dense baseline lives in this repo; compare with nanoGPT externally.
  python scripts/time_scaling.py --T_list 1024,4096,16384,65536"""
import argparse
import os
import sys
import time

import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from treeattn import Config, TreeGPT

p = argparse.ArgumentParser()
p.add_argument('--T_list', default='1024,4096,16384,65536')
p.add_argument('--reps', type=int, default=2)
a = p.parse_args()
dev = 'cuda' if torch.cuda.is_available() else 'cpu'
model = TreeGPT(Config(rope_cap=256)).to(dev).eval()
print('T | seconds | us/token | peak GPU MB')
with torch.no_grad(), torch.autocast(dev, dtype=torch.float16, enabled=dev == 'cuda'):
    for T in [int(v) for v in a.T_list.split(',')]:
        x = torch.randint(0, 8192, (1, T), device=dev)
        model(x[:, :1024])                                           # warm-up
        if dev == 'cuda':
            torch.cuda.synchronize(), torch.cuda.reset_peak_memory_stats()
        t0 = time.time()
        for _ in range(a.reps):
            model(x)
        if dev == 'cuda':
            torch.cuda.synchronize()
        dt = (time.time() - t0) / a.reps
        print('%d | %.2f | %.1f | %.0f' % (T, dt, 1e6 * dt / T, torch.cuda.max_memory_allocated() / 2 ** 20 if dev == 'cuda' else 0), flush=True)
