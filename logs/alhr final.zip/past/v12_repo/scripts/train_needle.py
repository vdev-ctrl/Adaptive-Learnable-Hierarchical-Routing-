"""Train on the needle task with a length curriculum, then report recall by length x depth.
The routing loss (--route_weight) is what teaches the splitter to make the needle's index keys findable."""
import argparse
import math
import os
import sys
import time

import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from treeattn import Config, TreeGPT
from treeattn.evaluate import fmt_row, needle_accuracy
from treeattn.tasks import NeedleTask

p = argparse.ArgumentParser()
p.add_argument('--out', default='runs/needle')
p.add_argument('--lengths', default='128,256,512,1024,2048')
p.add_argument('--steps', type=int, default=500, help='steps per length stage')
p.add_argument('--steps_first', type=int, default=0, help='steps for the first (shortest) stage; 0 = same as --steps')
p.add_argument('--tokens_per_batch', type=int, default=16384)
p.add_argument('--n_needles', type=int, default=4)
p.add_argument('--n_queries', type=int, default=3)
p.add_argument('--n_key', type=int, default=16)
p.add_argument('--n_val', type=int, default=16)
p.add_argument('--lr', type=float, default=1e-3)
p.add_argument('--n_layer', type=int, default=4)
p.add_argument('--n_head', type=int, default=4)
p.add_argument('--n_embd', type=int, default=256)
p.add_argument('--wmax', type=int, default=16)
p.add_argument('--spike', type=int, default=1)
p.add_argument('--node_norm', default='mean', choices=['mean', 'sqrt', 'none'])
p.add_argument('--route_weight', type=float, default=0.3)
p.add_argument('--budget_mode', default='pred')
p.add_argument('--filler_bin', default='')
p.add_argument('--warm_route', type=float, default=0.0, help='routing loss weight during the warm phase')
p.add_argument('--warm_steps', type=int, default=0, help='first N steps read ALL keys (dense-equivalent) to form the circuit, then switch to tree selection; needs a small first length')
p.add_argument('--warm_until_loss', type=float, default=0.0, help='keep the warm phase going (after --warm_steps) until the smoothed answer loss is below this')
p.add_argument('--warm_max', type=int, default=0, help='hard cap on warm steps (0 = --steps_first)')
p.add_argument('--save_warm', default='', help='save a checkpoint at the moment the warm phase ends')
p.add_argument('--load_warm', default='', help='start from a saved warm checkpoint (skips the warm phase)')
p.add_argument('--eval_lengths', default='1024,4096,16384')
p.add_argument('--log_every', type=int, default=50)
p.add_argument('--seed', type=int, default=0)
a = p.parse_args()

torch.manual_seed(a.seed)
dev = 'cuda' if torch.cuda.is_available() else 'cpu'
task = NeedleTask(n_key=a.n_key, n_val=a.n_val, filler_bin=a.filler_bin or None, seed=a.seed)
cfg = Config(vocab_size=task.vocab_size, n_layer=a.n_layer, n_head=a.n_head, n_embd=a.n_embd, wmax=a.wmax,
             spike=bool(a.spike), route_weight=a.route_weight, budget_mode=a.budget_mode, node_norm=a.node_norm)
model = TreeGPT(cfg).to(dev)
print('device', dev, '| params %.2fM | vocab %d' % (sum(p.numel() for p in model.parameters()) / 1e6, cfg.vocab_size))
opt = torch.optim.AdamW(model.parameters(), lr=a.lr, betas=(0.9, 0.95), weight_decay=0.01)
use_amp = dev == 'cuda'
scaler = torch.amp.GradScaler('cuda', enabled=use_amp)
lengths = [int(v) for v in a.lengths.split(',')]
steps_first = a.steps_first or a.steps
total, step, skipped = steps_first + a.steps * (len(lengths) - 1), 0, 0
L0 = lengths[0]
cur_full = None


def set_mode(full):
    if full:
        cfg.wmax, cfg.max_keys, cfg.budget_mode, cfg.fixed_budget, cfg.neighbors = L0 // 2, L0 + 8, 'fixed', L0 // 2, False
        cfg.route_weight = a.warm_route
    else:
        cfg.wmax, cfg.max_keys, cfg.budget_mode, cfg.fixed_budget, cfg.neighbors = a.wmax, 40, a.budget_mode, 4, True
        cfg.route_weight = a.route_weight


use_warm = a.warm_steps > 0 or bool(a.load_warm)
warm_max = a.warm_max or steps_first
warm_done = bool(a.load_warm)
ema = None
resume_it = 0
if use_warm:
    assert a.warm_steps <= warm_max <= steps_first
if a.load_warm:
    ck = torch.load(a.load_warm, map_location=dev, weights_only=False)
    model.load_state_dict(ck['model'])
    step = resume_it = ck['step']
    print('loaded warm checkpoint from step %d (optimizer state is fresh)' % step, flush=True)
os.makedirs(a.out, exist_ok=True)

for stage, T in enumerate(lengths):
    n_steps = steps_first if stage == 0 else a.steps
    b = max(1, a.tokens_per_batch // T)
    t0 = time.time()
    for it in range(resume_it if stage == 0 else 0, n_steps):
        lr = a.lr * min(1.0, (step + 1) / 100) * (0.1 + 0.9 * 0.5 * (1 + math.cos(math.pi * step / total)))
        for g in opt.param_groups:
            g['lr'] = lr
        if use_warm:
            if not warm_done and step >= a.warm_steps:
                formed = ema is not None and (a.warm_until_loss <= 0 or ema <= a.warm_until_loss)
                if formed or step >= warm_max:
                    warm_done = True
                    print('  >>> warm phase ends at step %d, smoothed lm %.3f %s' % (
                        step, ema if ema is not None else float('nan'),
                        '(circuit formed)' if formed else '(WARNING: threshold NOT reached, switching anyway)'), flush=True)
                    if a.save_warm:
                        os.makedirs(os.path.dirname(a.save_warm) or '.', exist_ok=True)
                        torch.save({'model': model.state_dict(), 'step': step, 'ema': ema}, a.save_warm)
            want_full = not warm_done
            if want_full != cur_full:
                set_mode(want_full)
                cur_full = want_full
                print('  >>> %s selection from step %d' % ('FULL-READ (warm start)' if want_full else 'TREE', step), flush=True)
        model.train()
        idx, y, route, _ = task.sample(b, T, n_needles=a.n_needles, n_queries=a.n_queries)
        idx, y, route = idx.to(dev), y.to(dev), tuple(r.to(dev) for r in route)
        with torch.autocast(dev, dtype=torch.float16, enabled=use_amp):
            _, loss, st = model(idx, y, route)
        if not torch.isfinite(loss):
            skipped += 1
            if skipped <= 3:
                print('  NON-FINITE loss at step %d: %s | spike thr per layer: %s' % (
                    step, {k: round(v, 3) for k, v in st.items() if not isinstance(v, list)}, [b_.attn.spike.thr.tolist() for b_ in model.blocks]), flush=True)
            if skipped > 100:
                raise SystemExit('too many non-finite steps, stopping')
            step += 1
            continue
        ema = st['lm'] if ema is None else 0.97 * ema + 0.03 * st['lm']
        opt.zero_grad(set_to_none=True)
        scaler.scale(loss).backward()
        scaler.unscale_(opt)
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        scaler.step(opt)
        scaler.update()
        step += 1
        if it % a.log_every == 0 or it == n_steps - 1:
            print('T %d step %d | lm %.3f route %.3f pred %.3f | keys %.1f flag %.3f | needle-hit/layer %s | %.2fs/step' % (
                T, step, st['lm'], st['route'], st['pred'], st.get('keys', 0), st.get('flag_frac', 0), ' '.join('%.2f' % h for h in st.get('hit', [])),
                (time.time() - t0) / (it + 1)), flush=True)
    r = needle_accuracy(model, task, T, depths=(0.1, 0.5, 0.9), n=24, n_needles=a.n_needles, amp=use_amp)
    print('  END OF STAGE T=%d | %s' % (T, fmt_row(r)), flush=True)
    torch.save({'cfg': cfg.to_dict(), 'model': model.state_dict(), 'task': dict(n_filler=task.n_filler, n_key=task.n_key, n_val=task.n_val)},
               os.path.join(a.out, 'ckpt.pt'))

print('\n=== FINAL: needle recall, first token / all three (chance ~ %.3f)' % (1.0 / task.n_val))
for T in [int(v) for v in a.eval_lengths.split(',')]:
    r = needle_accuracy(model, task, T, n=24, n_needles=a.n_needles, amp=use_amp)
    print('T=%6d | %s' % (T, fmt_row(r)), flush=True)
