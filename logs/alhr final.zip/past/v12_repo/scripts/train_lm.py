"""Language-model stage: train the full mini LLM (tree attention + FFN, next-token loss on every position) and report validation
loss / top-1 accuracy BY POSITION BUCKET at longer evaluation lengths. Resumes from out/ckpt.pt. Pure tree attention: no dense
attention exists in this repo, in training or in inference.

  python scripts/train_lm.py --data_dir data/wiki --out runs/lm_tree --labels_dir data/wiki_labels
Selection is taught by routing labels that an EXTERNAL dense model extracted beforehand (external/extract_needles.py): for each
labelled training window and layer, rows (query position, key position) the dense model attended to outside the cheap stages.
They are used exactly like the needle labels of the MQAR runs (the contrastive routing loss, --route_weight). Without
--labels_dir there is no routing signal (route_weight is forced to 0) and selection is learned only indirectly."""
import argparse
import json
import math
import os
import sys
import time

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from treeattn import Config, TreeGPT
from treeattn.lmdata import bucket_line, labeled_batch, load_labels, train_batch, val_windows, window, window_order

p = argparse.ArgumentParser()
p.add_argument('--data_dir', default='data/wiki')
p.add_argument('--out', default='runs/lm_tree')
p.add_argument('--labels_dir', default='', help='routing labels extracted by external/extract_needles.py (optional)')
p.add_argument('--route_weight', type=float, default=0.3)
p.add_argument('--seed', type=int, default=0)
p.add_argument('--seq_len', type=int, default=1024)
p.add_argument('--eval_lens', default='1024,2048,4096,8192,16384')
p.add_argument('--val_windows', type=int, default=24)
p.add_argument('--batch', type=int, default=16)
p.add_argument('--steps', type=int, default=4000)
p.add_argument('--lr', type=float, default=1e-3)
p.add_argument('--warmup', type=int, default=100)
p.add_argument('--n_layer', type=int, default=8)
p.add_argument('--n_head', type=int, default=6)
p.add_argument('--n_embd', type=int, default=384)
p.add_argument('--wmax', type=int, default=32, help='beam width = most leaf groups (2 keys each) the tree can add per query')
p.add_argument('--beam_classes', default='2,4,8,16,32', help='budget classes in leaf groups; the largest must be <= wmax')
p.add_argument('--max_keys', type=int, default=96, help='hard cap on keys read per query (a constant: cost stays O(T * max_keys))')
p.add_argument('--q_chunk', type=int, default=256, help='queries processed at once (lower it when the read budget is large)')
p.add_argument('--log_every', type=int, default=50)
p.add_argument('--val_every', type=int, default=500)
p.add_argument('--save_every', type=int, default=250)
p.add_argument('--spike', type=int, default=0)
p.add_argument('--spike_scale', default='levels', choices=['d', 'sqrt_n', 'levels'])
p.add_argument('--spike_amp', type=float, default=5.0)
p.add_argument('--rope_cap', type=int, default=0, help='0 = auto = seq_len')
a = p.parse_args()

dev = 'cuda' if torch.cuda.is_available() else 'cpu'
meta = json.load(open(os.path.join(a.data_dir, 'meta.json')))
labels = load_labels(a.labels_dir) if a.labels_dir else None
cfg = Config(vocab_size=meta['vocab'], seq_len=a.seq_len, n_layer=a.n_layer, n_head=a.n_head, n_embd=a.n_embd,
             route_weight=a.route_weight if labels else 0.0, spike=bool(a.spike), spike_scale=a.spike_scale, spike_amp=a.spike_amp,
             rope_cap=a.rope_cap or a.seq_len, wmax=a.wmax, beam_classes=tuple(int(v) for v in a.beam_classes.split(',')),
             max_keys=a.max_keys, q_chunk=a.q_chunk)
model = TreeGPT(cfg).to(dev)
if labels:
    lm_, lq, lt = labels
    assert lm_['T'] == a.seq_len and lm_['n_layer'] == a.n_layer, 'labels were extracted for a different window / depth'
print('device %s | params %.2fM | seq_len %d | batch %d x %d tokens | steps %d | spike %s | routing labels %s (route_weight %.2f) | '
      'rope_cap %d | wmax %d classes %s max_keys %d' % (
          dev, sum(q.numel() for q in model.parameters()) / 1e6, a.seq_len, a.batch, a.seq_len, a.steps, bool(a.spike),
          ('%d windows' % labels[0]['n_windows']) if labels else 'none', cfg.route_weight, cfg.rope_cap, cfg.wmax, a.beam_classes,
          cfg.max_keys), flush=True)
tr = np.memmap(os.path.join(a.data_dir, 'train.bin'), dtype=np.uint16, mode='r')
va = np.memmap(os.path.join(a.data_dir, 'val.bin'), dtype=np.uint16, mode='r')
cross = bool(meta.get('cross_docs', False))
opt = torch.optim.AdamW(model.parameters(), lr=a.lr, betas=(0.9, 0.95), weight_decay=0.1)
use_amp = dev == 'cuda'
scaler = torch.amp.GradScaler('cuda', enabled=use_amp)
os.makedirs(a.out, exist_ok=True)
ckpt_path = os.path.join(a.out, 'ckpt.pt')
step = 0
if os.path.exists(ckpt_path):
    ck = torch.load(ckpt_path, map_location=dev, weights_only=False)
    model.load_state_dict(ck['model'])
    opt.load_state_dict(ck['opt'])
    step = ck['step']
    print('resumed at step', step, flush=True)


def save():
    torch.save({'cfg': cfg.to_dict(), 'model': model.state_dict(), 'opt': opt.state_dict(), 'step': step, 'meta': meta}, ckpt_path)


@torch.no_grad()
def evaluate(T, n):
    model.eval()
    starts = val_windows(va, meta['eot'], T, n, cross=cross)
    tot = hit = None
    for s in starts:
        x, y = window(va, s, T, dev)
        with torch.autocast(dev, dtype=torch.float16, enabled=use_amp):
            lg, _, _ = model(x)
        ce = torch.nn.functional.cross_entropy(lg.float().view(-1, lg.size(-1)), y.view(-1), reduction='none')
        ok = (lg.argmax(-1).view(-1) == y.view(-1)).float()
        tot, hit = (ce, ok) if tot is None else (tot + ce, hit + ok)
    model.train()
    return tot / max(len(starts), 1), hit / max(len(starts), 1), len(starts)


t_start, n_done, ema, bad = time.time(), 0, None, 0
while step < a.steps:
    lr = a.lr * min(1.0, (step + 1) / a.warmup) * (0.1 + 0.9 * 0.5 * (1 + math.cos(math.pi * step / a.steps)))
    for g in opt.param_groups:
        g['lr'] = lr
    model.train()
    if labels:
        x, y, routes = labeled_batch(tr, a.seq_len, window_order(lm_['n_windows'], a.batch, step, a.seed), lq, lt, dev)
    else:
        x, y = train_batch(tr, a.batch, a.seq_len, step, a.seed, dev)
        routes = None
    with torch.autocast(dev, dtype=torch.float16, enabled=use_amp):
        _, loss, st = model(x, y, routes)
    if not torch.isfinite(loss):
        bad += 1
        print('non-finite loss at step', step, '- skipped (%d in a row)' % bad, flush=True)
        if bad >= 20:
            raise SystemExit('training diverged: 20 non-finite steps in a row, stopping instead of wasting the session')
        step += 1
        continue
    bad = 0
    opt.zero_grad(set_to_none=True)
    scaler.scale(loss).backward()
    scaler.unscale_(opt)
    torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
    scaler.step(opt)
    scaler.update()
    step += 1
    n_done += 1
    ema = st['lm'] if ema is None else 0.98 * ema + 0.02 * st['lm']
    if step % a.log_every == 0 or step == 1:
        print('step %d | lm %.3f (ema %.3f) pred %.3f route %.3f | label-hit/layer %s | keys %.1f | lr %.1e | %.2fs/step' % (
            step, st['lm'], ema, st['pred'], st.get('route', 0), ' '.join('%.2f' % h for h in st.get('hit', [])), st.get('keys', 0), lr,
            (time.time() - t_start) / n_done), flush=True)
        if 'chist' in st and (step % (a.log_every * 4) == 0 or step == 1):
            print('    budget classes %s, share of queries per class per layer: %s' % (a.beam_classes, ' '.join(
                '[' + ','.join('%.2f' % v for v in h) + ']' for h in st['chist'])), flush=True)
    if step % a.val_every == 0:
        ce, ac, n = evaluate(a.seq_len, 16)
        print('  VAL step %d | T=%d | loss %.3f acc %.3f (%d windows)' % (step, a.seq_len, ce.mean().item(), ac.mean().item(), n), flush=True)
    if step % a.save_every == 0 or step == a.steps:
        save()

print('\n=== FINAL validation loss by position bucket (nats/token and next-token top-1 accuracy; same fixed windows for every model). Trained at %d.' % a.seq_len)
for T in [int(v) for v in a.eval_lens.split(',')]:
    ce, ac, n = evaluate(T, a.val_windows)
    print('T=%-6d (%d windows) %s' % (T, n, bucket_line(ce, ac, T, a.seq_len)), flush=True)
