"""Inference check on a trained LM checkpoint (tree attention only, no dense code, eval mode, fp32):
 1. cached token-by-token decoding must reproduce the parallel forward pass (same logits, same top-1 token);
 2. greedy text generation through the cached path from a real validation prompt (printed if tokenizer.json is present).
  python scripts/check_decode.py --ckpt runs/lm_tree/ckpt.pt --data_dir data/pg19"""
import argparse
import json
import os
import sys

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from treeattn import Config, TreeGPT
from treeattn.lmdata import val_windows, window

p = argparse.ArgumentParser()
p.add_argument('--ckpt', required=True)
p.add_argument('--data_dir', default='data/pg19')
p.add_argument('--T', type=int, default=2048)
p.add_argument('--n_decode', type=int, default=64)
p.add_argument('--n_gen', type=int, default=60)
a = p.parse_args()
dev = 'cuda' if torch.cuda.is_available() else 'cpu'
ck = torch.load(a.ckpt, map_location=dev, weights_only=False)
cfg = Config(**ck['cfg'])
model = TreeGPT(cfg).to(dev)
model.load_state_dict(ck['model'])
model.eval()
meta = json.load(open(os.path.join(a.data_dir, 'meta.json')))
va = np.memmap(os.path.join(a.data_dir, 'val.bin'), dtype=np.uint16, mode='r')
x, _ = window(va, val_windows(va, meta['eot'], a.T, 1, cross=bool(meta.get('cross_docs', False)))[0], a.T, dev)
pre = a.T - a.n_decode
with torch.no_grad():
    ref, _, _ = model(x)                                            # parallel forward over the whole window
    caches = model.new_caches(1, a.T)
    model(x[:, :pre], caches=caches)                                # prefill the prompt in parallel
    outs = []
    for t in range(pre, a.T):                                       # then one cached token at a time
        lg, _, _ = model(x[:, t:t + 1], caches=caches)
        outs.append(lg[:, 0])
    dec = torch.stack(outs, 1)
ref = ref[:, pre:]
print('DECODE CHECK | window %d, last %d tokens decoded one by one through the cache' % (a.T, a.n_decode))
print('  max |logit difference| %.2e | top-1 token agreement %.1f%%' % ((dec - ref).abs().max().item(), 100 * (dec.argmax(-1) == ref.argmax(-1)).float().mean().item()))
tokp = os.path.join(a.data_dir, 'tokenizer.json')
with torch.no_grad():
    out = model.generate(x[:, :1024], a.n_gen)
if os.path.exists(tokp):
    from tokenizers import Tokenizer
    tok = Tokenizer.from_file(tokp)
    print('  PROMPT (last 300 chars): ...' + tok.decode(x[0, :1024].tolist())[-300:].replace('\n', ' '))
    print('  GENERATED (cached path):', tok.decode(out[0, 1024:].tolist()).replace('\n', ' '))
else:
    print('  generated token ids:', out[0, -a.n_gen:].tolist())
