"""Needle-in-Wikipedia + free-prompt demo for a trained tree LM (eval mode, tree attention only).
  python scripts/needle_eval.py --ckpt runs/lm_tree/ckpt.pt --data_dir data/wiki --out runs/demo_tree.txt
--tree_off 1 reads no tree leaves (static + neighbour keys only): the loss of accuracy against the normal run is what the tree adds."""
import argparse
import json
import os
import sys

import numpy as np
import torch
from tokenizers import Tokenizer

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from treeattn import Config, TreeGPT
from treeattn.needles import FREE_PROMPTS, answer_ids_from_vocab, needle_demo, run_needle_eval

p = argparse.ArgumentParser()
p.add_argument('--ckpt', required=True)
p.add_argument('--data_dir', default='data/wiki')
p.add_argument('--lengths', default='512,1024,2048,4096,8192,16384')
p.add_argument('--depths', default='0.1,0.3,0.5,0.7,0.9')
p.add_argument('--min_answer_id', type=int, default=3000, help='answer words are whole-word tokens with id >= this (rarer words)')
p.add_argument('--n', type=int, default=20, help='cases per (length, depth)')
p.add_argument('--tree_off', type=int, default=0)
p.add_argument('--gen', type=int, default=40)
p.add_argument('--out', default='')
a = p.parse_args()
dev = 'cuda' if torch.cuda.is_available() else 'cpu'
ck = torch.load(a.ckpt, map_location=dev, weights_only=False)
cfg = Config(**ck['cfg'])
cfg.tree_off = bool(a.tree_off)
model = TreeGPT(cfg).to(dev)
model.load_state_dict(ck['model'])
model.eval()
tok = Tokenizer.from_file(os.path.join(a.data_dir, 'tokenizer.json'))
enc, dec = (lambda s: tok.encode(s).ids), (lambda ids: tok.decode(list(ids)))
val = np.memmap(os.path.join(a.data_dir, 'val.bin'), dtype=np.uint16, mode='r')
answer_ids = answer_ids_from_vocab(tok.get_vocab(), min_id=a.min_answer_id)
use_amp = dev == 'cuda'


@torch.no_grad()
def logits_fn(ids):
    x = torch.tensor([ids], device=dev)
    with torch.autocast(dev, dtype=torch.float16, enabled=use_amp):
        lg, _, _ = model(x)
    return lg[0, -1].float().cpu().numpy()


@torch.no_grad()
def gen_fn(ids, n):
    x = torch.tensor([ids], device=dev)
    return model.generate(x, n)[0, len(ids):].tolist()


out = ['NEEDLE-IN-WIKIPEDIA | model: tree attention%s | %d answer words (guess rate ~%.2f%%) | cases per cell: %d' % (
    ' (TREE OFF: static + neighbour keys only)' if a.tree_off else '', len(answer_ids), 100.0 / len(answer_ids), a.n)]
depths = [float(v) for v in a.depths.split(',')]
out.append('accuracy of the hidden word as the next token, by prompt length (rows) and depth of the queried fact (columns); last column = control without the fact')
out.append('length   ' + ' '.join('%5d%%' % int(d * 100) for d in depths) + '  | control')
for L in [int(v) for v in a.lengths.split(',')]:
    res, ctrl = run_needle_eval(logits_fn, val, enc, answer_ids, L, depths, a.n, seed=1)
    out.append('%-8d ' % L + ' '.join('%6.2f' % res[d] for d in depths) + '  | %.2f' % ctrl)
    print(out[-1], flush=True)
out.append('')
out.append('=== WHAT THE MODEL SAYS (greedy) ===')
out.append(needle_demo(logits_fn, gen_fn, val, enc, dec, answer_ids, L=1024, depth=0.5))
out.append(needle_demo(logits_fn, gen_fn, val, enc, dec, answer_ids, L=4096, depth=0.2, seed=8))
for pr in FREE_PROMPTS:
    out.append('  PROMPT: %r' % pr)
    out.append('  ANSWER: %r' % dec(gen_fn(enc(pr), a.gen)))
text = '\n'.join(out)
print('\n' + text)
if a.out:
    open(a.out, 'w').write(text)
