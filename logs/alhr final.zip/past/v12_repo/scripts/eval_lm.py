"""Position-bucket loss / accuracy of a trained tree LM checkpoint, optionally with --tree_off 1 (no tree leaves are read).
  python scripts/eval_lm.py --ckpt runs/lm_tree/ckpt.pt --data_dir data/wiki --tree_off 1"""
import argparse
import json
import os
import sys

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from treeattn import Config, TreeGPT
from treeattn.lmdata import bucket_line, val_windows, window

p = argparse.ArgumentParser()
p.add_argument('--ckpt', required=True)
p.add_argument('--data_dir', default='data/wiki')
p.add_argument('--eval_lens', default='1024,4096,16384')
p.add_argument('--val_windows', type=int, default=24)
p.add_argument('--tree_off', type=int, default=0)
a = p.parse_args()
dev = 'cuda' if torch.cuda.is_available() else 'cpu'
ck = torch.load(a.ckpt, map_location=dev, weights_only=False)
cfg = Config(**ck['cfg'])
cfg.tree_off = bool(a.tree_off)
model = TreeGPT(cfg).to(dev)
model.load_state_dict(ck['model'])
model.eval()
meta = json.load(open(os.path.join(a.data_dir, 'meta.json')))
va = np.memmap(os.path.join(a.data_dir, 'val.bin'), dtype=np.uint16, mode='r')
print('EVAL | tree %s | trained at %d' % ('OFF (static + neighbour keys only)' if a.tree_off else 'on', cfg.seq_len))
for T in [int(v) for v in a.eval_lens.split(',')]:
    tot = hit = None
    starts = val_windows(va, meta['eot'], T, a.val_windows, cross=bool(meta.get('cross_docs', False)))
    for s in starts:
        x, y = window(va, s, T, dev)
        with torch.no_grad(), torch.autocast(dev, dtype=torch.float16, enabled=dev == 'cuda'):
            lg, _, _ = model(x)
        ce = torch.nn.functional.cross_entropy(lg.float().view(-1, lg.size(-1)), y.view(-1), reduction='none')
        ok = (lg.argmax(-1).view(-1) == y.view(-1)).float()
        tot, hit = (ce, ok) if tot is None else (tot + ce, hit + ok)
    print('T=%-6d (%d windows) %s' % (T, len(starts), bucket_line(tot / len(starts), hit / len(starts), T, cfg.seq_len)), flush=True)
