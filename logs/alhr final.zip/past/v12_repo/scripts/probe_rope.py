"""Is the long-range failure caused by RoPE distances the model never saw in training? Inference only.

Same checkpoint, same data for every variant. Variant "cap C" makes exact attention see every key at relative distance
<= C (keys farther away are rotated as if they were exactly C away). The tree never uses the rotated dims, so selection is
untouched and only the exact-attention scores change. SPIKE IS OFF in every variant: the checkpoint may have been trained
with a different spike scale than the current code, so spike-off is the one condition that is identical for all.

Reading it: if accuracy at gaps > cap rises a lot with the cap, the position encoding was a main cause. If it does not move,
the hypothesis is ruled out.     python scripts/probe_rope.py --ckpt runs/mqar_sqrtn/ckpt.pt
"""
import argparse
import os
import sys

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from treeattn import Config, TreeGPT
from treeattn.tasks import MQARTask

BUCKETS = [(0, 256), (256, 1024), (1024, 4096), (4096, 16384)]


@torch.no_grad()
def run(model, vocab, T, n_kv, n, seed, amp, dev):
    task = MQARTask(vocab_size=vocab, seed=seed)
    ok, cnt = {i: 0 for i in range(len(BUCKETS))}, {i: 0 for i in range(len(BUCKETS))}
    tot_ok = tot = 0
    for _ in range(n):
        idx, y, route = task.sample(1, T, n_kv)
        with torch.autocast(dev.type, dtype=torch.float16, enabled=amp):
            logits, _, _ = model(idx.to(dev), route=tuple(r.to(dev) for r in route))
        bi, qp, tg = route
        good = (logits[0, qp.to(dev)].argmax(-1).cpu() == y[bi, qp])
        gap = (qp - tg).numpy()
        tot_ok += int(good.sum())
        tot += len(good)
        for i, (lo, hi) in enumerate(BUCKETS):
            m = (gap >= lo) & (gap < hi)
            ok[i] += int(good.numpy()[m].sum())
            cnt[i] += int(m.sum())
    cells = ['%.2f(n=%d)' % (ok[i] / cnt[i], cnt[i]) if cnt[i] else '  -  ' for i in range(len(BUCKETS)) if BUCKETS[i][0] < T]
    return tot_ok / tot, cells


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--ckpt', required=True)
    p.add_argument('--T_list', default='1024,4096,16384')
    p.add_argument('--n_kv', type=int, default=16)
    p.add_argument('--n', type=int, default=24)
    p.add_argument('--caps', default='256,128')
    p.add_argument('--seed', type=int, default=1234)
    a = p.parse_args()
    dev = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    amp = dev.type == 'cuda'
    ck = torch.load(a.ckpt, map_location=dev, weights_only=False)
    cfg = Config(**ck['cfg'])
    model = TreeGPT(cfg).to(dev)
    model.load_state_dict(ck['model'])
    model.eval()
    print('loaded %s | step %s | trained stages %s' % (a.ckpt, ck.get('step'), ck.get('stages', 'single T=256 (v4)')))
    variants = [('spike off, no cap (reference)', 0)] + [('spike off, cap %s' % c, int(c)) for c in a.caps.split(',')]
    print('gap buckets: ' + ' | '.join('%d-%d' % b for b in BUCKETS))
    cfg.spike = False
    for T in [int(v) for v in a.T_list.split(',')]:
        print('\nT=%d, %d sequences x %d answers each variant (+-3%% noise at 1 sigma overall, more per bucket)' % (T, a.n, a.n_kv))
        for name, cap in variants:
            cfg.rope_cap = cap
            acc, cells = run(model, ck['vocab'], T, a.n_kv, a.n, a.seed, amp, dev)
            print('  %-32s acc %.3f | %s' % (name, acc, ' | '.join(cells)), flush=True)


if __name__ == '__main__':
    main()
