"""TinyStories -> BPE tokenizer + flat uint16 token files (for the LM stage, not needed for the needle test)."""
import argparse
import os

import numpy as np

p = argparse.ArgumentParser()
p.add_argument('--out', default='data/tinystories')
p.add_argument('--n_stories', type=int, default=150000)
p.add_argument('--val_stories', type=int, default=2000)
p.add_argument('--vocab', type=int, default=8192)
a = p.parse_args()
os.makedirs(a.out, exist_ok=True)
from datasets import load_dataset
from tokenizers import Tokenizer, decoders, models, pre_tokenizers, trainers


def take(split, n):
    out = []
    for ex in load_dataset('roneneldan/TinyStories', split=split, streaming=True):
        if len(ex['text'].strip()) >= 50:
            out.append(ex['text'].strip())
        if len(out) >= n:
            break
    return out


tr_txt, va_txt = take('train', a.n_stories), take('validation', a.val_stories)
tok = Tokenizer(models.BPE())
tok.pre_tokenizer = pre_tokenizers.ByteLevel(add_prefix_space=False)
tok.decoder = decoders.ByteLevel()
tok.train_from_iterator(tr_txt[:50000], trainers.BpeTrainer(vocab_size=a.vocab, special_tokens=['<|endoftext|>'],
                                                           initial_alphabet=pre_tokenizers.ByteLevel.alphabet()))
tok.save(os.path.join(a.out, 'tokenizer.json'))
eot = tok.token_to_id('<|endoftext|>')


def encode(texts):
    ids = []
    for enc in tok.encode_batch(texts):
        ids.extend(enc.ids + [eot])
    return np.array(ids, dtype=np.uint16)


encode(tr_txt).tofile(os.path.join(a.out, 'train.bin'))
encode(va_txt).tofile(os.path.join(a.out, 'val.bin'))
print('done, vocab', tok.get_vocab_size())
