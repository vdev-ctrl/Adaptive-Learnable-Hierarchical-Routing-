"""Run with: python -m pytest tests -q   (CPU is fine, everything is tiny)."""
import os
import sys

import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from treeattn import Config, TreeGPT
from treeattn.spike import Spike
from treeattn.tasks import NeedleTask
from treeattn.tree import build_levels, next_pow2, tree_descent


def small_cfg(**kw):
    base = dict(vocab_size=64, n_layer=2, n_head=2, n_embd=64, rot_dims=8, wmax=8, beam_classes=(2, 3, 4, 6, 8), q_chunk=32)
    base.update(kw)
    return Config(**base)


def arm_spike(model, thr=1.1):
    for blk in model.blocks:
        blk.attn.spike.thr.fill_(thr)
        blk.attn.spike.gthr.fill_(1.0)
        blk.attn.spike.thr_init.fill_(1.0)


def test_descent_covers_exactly_the_past():
    torch.manual_seed(0)
    T = 64
    k = torch.randn(1, 1, T, 8)
    S = build_levels(k, next_pow2(T))
    tq = torch.arange(T)
    ids, vld, _ = tree_descent(torch.randn(1, 1, T, 8), S, tq, wmax=64)
    for t in range(T):
        got = sorted(ids[0, 0, t][vld[0, 0, t]].tolist())
        want = [m for m in range(T // 2) if 2 * m + 1 < t]       # leaves entirely before t
        assert got == want, (t, got, want)


def test_spike_is_causal_and_flags_outlier():
    cfg = small_cfg()
    sp = Spike(cfg)
    x = torch.randn(1, 200, 16)
    s1, _ = sp.scores(x, sp.stats_parallel(x))
    x2 = x.clone()
    x2[:, 150:] += 5.0                                        # change the future of positions < 150
    s2, _ = sp.scores(x2, sp.stats_parallel(x2))
    assert torch.allclose(s1[:, :150], s2[:, :150], atol=1e-4)
    x3 = x.clone()
    x3[:, 120] += 10.0 * torch.randn(16)
    s3, _ = sp.scores(x3, sp.stats_parallel(x3))
    assert s3[0, 120] > 3 * s1[0, 120].clamp(min=1.0)


def test_spike_stats_decode_equals_parallel():
    cfg = small_cfg()
    sp = Spike(cfg)
    x = torch.randn(2, 150, 16) * 2 + 1
    mu, sd, n, gm, gsd = sp.stats_parallel(x)
    gs, gs2 = torch.zeros(2, 16, dtype=torch.float64), torch.zeros(2, 16, dtype=torch.float64)
    for t in range(150):
        lo = max(1, t - cfg.spike_win)
        m1, s1_, n1, g1, gs1 = sp.stats_step(x[:, lo:t], gs, gs2, max(t - 1, 0))
        assert int(n1) == int(n[t])
        for a_, b_ in ((m1[:, 0], mu[:, t]), (s1_[:, 0], sd[:, t]), (g1[:, 0], gm[:, t]), (gs1[:, 0], gsd[:, t])):
            assert torch.allclose(a_, b_, atol=1e-4), (t, (a_ - b_).abs().max())
        if t >= 1:
            gs += x[:, t].double()
            gs2 += (x[:, t] ** 2).double()


def test_multiplier_gradient_reaches_tokens_and_sqrt_n_grows():
    cfg = small_cfg(spike_scale='sqrt_n', spike_amp=3.0)
    sp = Spike(cfg)
    sp.thr.fill_(1.2), sp.gthr.fill_(1.0), sp.thr_init.fill_(1.0)
    x = torch.randn(1, 128, 16, requires_grad=True)
    s, _ = sp.scores(x, sp.stats_parallel(x))
    mult = sp.multiplier(s, 128)
    mult.sum().backward()
    assert x.grad.abs().sum() > 0 and (mult >= 1).all()
    s_eq = torch.full((1, 2), 3.0)
    m16, m1024 = sp.multiplier(s_eq, 16), sp.multiplier(s_eq, 1024)       # scale = sqrt of the TOTAL window, not of the position
    assert (m1024 > m16).all() and (m16 > 1.0).all()
    assert torch.allclose(m16[:, 0], m16[:, 1])                           # same score -> same multiplier at every position


def test_no_future_leak_with_amplification():
    torch.manual_seed(1)
    model = TreeGPT(small_cfg()).eval()
    arm_spike(model)
    x = torch.randint(0, 64, (1, 128))
    base, _, _ = model(x)
    j = 90
    x2 = x.clone()
    x2[0, j:] = torch.randint(0, 64, (128 - j,))
    alt, _, _ = model(x2)
    assert torch.allclose(base[:, :j], alt[:, :j], atol=1e-5), (base[:, :j] - alt[:, :j]).abs().max()


def test_decode_matches_parallel():
    torch.manual_seed(2)
    model = TreeGPT(small_cfg()).eval()
    arm_spike(model)
    x = torch.randint(0, 64, (1, 96))
    full, _, _ = model(x)
    caches = model.new_caches(1, 96)
    lg, _, _ = model(x[:, :48], caches=caches)
    outs = [lg]
    for t in range(48, 96):
        lg, _, _ = model(x[:, t:t + 1], caches=caches)
        outs.append(lg)
    step = torch.cat(outs, 1)
    assert torch.allclose(full, step, atol=1e-3), (full - step).abs().max()


def test_train_step_gives_gradients_to_both_trainable_functions():
    torch.manual_seed(3)
    task = NeedleTask(n_filler=32, n_key=8, n_val=16)
    cfg = small_cfg(vocab_size=task.vocab_size)
    model = TreeGPT(cfg).train()
    idx, y, route, _ = task.sample(2, 256, n_needles=3)
    for _ in range(2):                                          # second step has an initialised spike threshold
        model.zero_grad()
        _, loss, st = model(idx, y, route)
        loss.backward()
    assert torch.isfinite(loss)
    a = model.blocks[1].attn
    assert a.qkv.weight.grad.abs().sum() > 0                     # splitter
    assert a.pred[0].weight.grad is not None and a.pred[0].weight.grad.abs().sum() > 0   # budget predictor
    assert st['route'] != 0.0


def test_needle_task_layout():
    task = NeedleTask(n_filler=32, n_key=8, n_val=16)
    idx, y, (qpos, tgt), ans = task.sample(3, 300, n_needles=4, depth=0.5)
    assert idx.shape == (3, 300) and (y != -100).sum(1).tolist() == [3, 3, 3]
    for i in range(3):
        assert idx[i, qpos[i]] == idx[i, tgt[i] - 1]          # question key == needle key
        assert idx[i, tgt[i]] == ans[i, 0]


def test_multi_question_layout():
    task = NeedleTask(n_filler=32, n_key=8, n_val=16)
    idx, y, (qpos, tgt), ans = task.sample(2, 400, n_needles=4, n_queries=3, depth=0.3)
    assert (y != -100).sum(1).tolist() == [9, 9]
    for i in range(2):
        assert idx[i, qpos[i]] == idx[i, tgt[i] - 1] and idx[i, tgt[i]] == y[i, qpos[i]]


def test_mqar_layout_and_multi_query_routing():
    from treeattn.tasks import MQARTask
    task = MQARTask(vocab_size=128)
    idx, y, (bi, qp, tg) = task.sample(2, 128, 8)
    assert idx.shape == (2, 128) and (y != -100).sum(1).tolist() == [8, 8]
    assert (idx[bi, qp] == idx[bi, tg - 1]).all() and (y[bi, qp] == idx[bi, tg]).all()
    torch.manual_seed(5)
    cfg = small_cfg(vocab_size=128)
    model = TreeGPT(cfg).train()
    for _ in range(2):
        model.zero_grad()
        _, loss, st = model(idx, y, (bi, qp, tg))
        loss.backward()
    assert torch.isfinite(loss) and st['route'] != 0.0 and len(st['hit']) == cfg.n_layer


def _run_decode(model, x, prefill):
    T = x.shape[1]
    caches = model.new_caches(1, T)
    lg, _, _ = model(x[:, :prefill], caches=caches)
    outs = [lg]
    for t in range(prefill, T):
        lg, _, _ = model(x[:, t:t + 1], caches=caches)
        outs.append(lg)
    return torch.cat(outs, 1)


def test_early_boost_changes_output_is_causal_and_decode_matches():
    torch.manual_seed(7)
    cfg_on, cfg_off = small_cfg(spike_early=True), small_cfg(spike_early=False)
    m_on, m_off = TreeGPT(cfg_on).eval(), TreeGPT(cfg_off).eval()
    m_off.load_state_dict(m_on.state_dict())
    arm_spike(m_on, thr=0.8), arm_spike(m_off, thr=0.8)
    x = torch.randint(0, 64, (1, 96))
    on, _, _ = m_on(x)
    off, _, _ = m_off(x)
    assert on[:, :16].allclose(off[:, :16], atol=1e-5)                    # queries t < spike_min_hist never see the boost
    a0 = m_on.blocks[0].attn                                              # the boost vector itself is non-zero (live); whether it changes
    d = a0._early_delta(torch.randn(1, 96, 64), torch.randn(1, 2, 96, 24), 128, None, 0, 96, False)   # the selected keys depends on the beam
    assert d is not None and d.shape == (1, 2, 24) and d.abs().sum() > 0
    x2 = x.clone()
    x2[0, 60:] = torch.randint(0, 64, (36,))
    assert on[:, :60].allclose(m_on(x2)[0][:, :60], atol=1e-5)            # still no future leak
    for prefill in (8, 48):                                               # 8: the boost is applied during decoding, 48: during prefill
        assert on.allclose(_run_decode(m_on, x, prefill), atol=1e-3), prefill


def test_rope_cap_equals_distance_cap_and_is_off_by_default():
    from treeattn.attention import rotary, rotate_extra
    torch.manual_seed(9)
    q, k = torch.randn(1, 1, 1, 16), torch.randn(1, 1, 1, 16)
    t, j, cap = torch.tensor([300]), torch.tensor([100]), 64
    far = (rotary(q, t, 8, 1e4) * rotary(k, j, 8, 1e4)).sum()                      # distance 200 -> not equal to the capped score
    k_cap = rotate_extra(rotary(k, j, 8, 1e4), (t - j - cap).clamp(min=0).view(1, 1, 1), 8, 1e4)
    got = (rotary(q, t, 8, 1e4) * k_cap).sum()
    want = (rotary(q, torch.tensor([cap]), 8, 1e4) * rotary(k, torch.tensor([0]), 8, 1e4)).sum()
    assert torch.allclose(got, want, atol=1e-4) and not torch.allclose(far, want, atol=1e-4)
    model = TreeGPT(small_cfg()).eval()
    x = torch.randint(0, 64, (1, 96))
    base, _, _ = model(x)
    model.cfg.rope_cap = 10 ** 6                                                  # cap beyond every distance: no change
    assert torch.allclose(base, model(x)[0], atol=1e-5)
    model.cfg.rope_cap = 8                                                        # real cap runs and stays finite
    assert torch.isfinite(model(x)[0]).all()


def test_train_script_arguments_parse_and_cap_defaults_to_longest_stage():
    import subprocess
    r = subprocess.run([sys.executable, '-c', 'import ast,sys; ast.parse(open(sys.argv[1]).read())',
                        os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'scripts', 'train_mqar.py')])
    assert r.returncode == 0


def test_val_windows_never_cross_a_book():
    import numpy as np
    from treeattn.lmdata import val_windows
    val = np.random.randint(1, 50, 20000).astype(np.uint16)
    val[[3000, 9000, 15000]] = 0
    for T in (64, 512, 2048):
        starts = val_windows(val, 0, T, 12)
        assert len(starts) == 12 and starts == val_windows(val, 0, T, 12)
        assert all(not (val[s:s + T + 1] == 0).any() for s in starts)


def _run(args):
    import subprocess
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    r = subprocess.run([sys.executable] + args, cwd=root, capture_output=True, text=True)
    assert r.returncode == 0, r.stdout[-1500:] + r.stderr[-1500:]
    return r.stdout


def test_prepare_pg19_from_local_text(tmp_path):
    import pytest
    pytest.importorskip('tokenizers')
    import json
    import numpy as np
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    src = tmp_path / 'books'
    src.mkdir()
    rng = np.random.default_rng(1)
    words = ['alpha', 'beta', 'gamma', 'delta', 'omega', 'river', 'stone', 'light', 'shadow', 'winter']
    for i in range(8):
        (src / ('b%d.txt' % i)).write_text(' '.join(rng.choice(words, 600)))
    out = tmp_path / 'pg'
    _run([os.path.join(root, 'scripts', 'prepare_pg19.py'), '--out', str(out), '--local_txt_dir', str(src), '--val_books', '2',
          '--tok_books', '4', '--vocab', '300', '--train_tokens', '1500'])
    meta = json.load(open(out / 'meta.json'))
    assert meta['train_tokens'] > 0 and meta['val_tokens'] > 0 and meta['vocab'] <= 300
    assert np.fromfile(out / 'train.bin', dtype=np.uint16).max() < meta['vocab']


def test_levels_scale_and_class_histogram():
    from treeattn.spike import Spike
    cfg = small_cfg(spike_scale='levels', spike_amp=2.0)
    sp = Spike(cfg)
    sp.thr_init.fill_(1.0), sp.thr.fill_(1.0)
    s = torch.full((1, 8), 3.0)
    m256, m4096 = sp.multiplier(s, 256), sp.multiplier(s, 4096)
    assert torch.allclose((m4096 - 1) / (m256 - 1), torch.tensor(12.0 / 8.0), atol=1e-4)     # grows with log2 N, not with N
    model = TreeGPT(small_cfg(route_weight=0.0))
    _, _, st = model(torch.randint(0, 64, (1, 64)))
    assert all(abs(sum(h) - 1.0) < 1e-4 for h in st['chist'])


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def test_repo_contains_no_dense_attention():
    import glob
    banned = ('scaled_dot_product_attention', 'dense_forward', '_guide_targets', 'guide_weight', 'dense_warmup')
    for f in glob.glob(os.path.join(ROOT, 'treeattn', '*.py')) + glob.glob(os.path.join(ROOT, 'scripts', '*.py')):
        src = open(f).read()
        for word in banned:
            assert word not in src, '%s still mentions %s' % (os.path.basename(f), word)


def test_per_layer_label_routes_train_and_report_hits(tmp_path):
    import numpy as np
    from treeattn.lmdata import PAD, labeled_batch, load_labels, window_order
    T, n_win, R, L = 64, 6, 8, 2
    rng = np.random.default_rng(0)
    q = rng.integers(10, T, (n_win, L, R)).astype(np.uint16)
    t = (q - rng.integers(3, 9, (n_win, L, R))).astype(np.uint16)
    q[0, 1, 4:], t[0, 1, 4:] = PAD, PAD                                       # some unused rows
    q[:, 0, :], t[:, 0, :] = PAD, PAD                                         # layer 0 has no labels
    q.tofile(tmp_path / 'labels_q.u16'), t.tofile(tmp_path / 'labels_t.u16')
    import json
    json.dump({'T': T, 'n_windows': n_win, 'n_layer': L, 'rows': R}, open(tmp_path / 'labels_meta.json', 'w'))
    meta, lq, lt = load_labels(str(tmp_path))
    data = rng.integers(1, 64, n_win * T + 8).astype(np.uint16)
    order = window_order(n_win, 4, 0, 1)
    assert len(set(order.tolist())) == 4
    x, y, routes = labeled_batch(data, T, order, lq, lt, 'cpu')
    assert x.shape == (4, T) and routes[0] is None and routes[1] is not None
    bi, qp, tg = routes[1]
    assert (tg < qp).all() and (qp < T).all() and bi.max() < 4
    model = TreeGPT(small_cfg(n_layer=L, route_weight=0.3))
    model.train()
    _, loss, st = model(x, y, routes)
    assert torch.isfinite(loss) and st['route'] > 0 and len(st['hit']) == 1       # one routed layer
    loss.backward()


def test_tree_off_changes_the_read_set_and_stays_finite():
    torch.manual_seed(4)
    model = TreeGPT(small_cfg()).eval()
    x = torch.randint(0, 64, (1, 120))
    on, _, _ = model(x)
    model.cfg.tree_off = True
    off, _, _ = model(x)
    model.cfg.tree_off = False
    assert torch.isfinite(off).all() and not torch.allclose(on, off, atol=1e-6)


def test_needle_builder_and_scoring_with_an_induction_oracle():
    import numpy as np
    from treeattn.needles import build_trial, run_needle_eval
    enc = lambda s: [ord(c) % 90 + 1 for c in s]
    answer_ids = list(range(100, 160))
    val = np.random.default_rng(0).integers(1, 90, 5000)
    rng = np.random.default_rng(1)
    ids, ans, info = build_trial(val, enc, answer_ids, 700, 0.4, rng)
    assert len(ids) == 700 and ans in answer_ids and ids[-len(enc(info['fact_prefix'])):] == enc(info['fact_prefix'])
    ids_c, ans_c, _ = build_trial(val, enc, answer_ids, 700, 0.4, np.random.default_rng(1), with_needle=False)
    assert len(ids_c) == 700

    def oracle(ids):                                                           # induction: copy what followed the query earlier
        suf, n = ids[-14:], len(ids)
        out = np.zeros(200)
        for i in range(n - 15, -1, -1):
            if ids[i:i + 14] == suf:
                out[ids[i + 14]] = 1.0
                break
        return out
    res, ctrl = run_needle_eval(oracle, val, enc, answer_ids, 700, [0.2, 0.8], 6, seed=3)
    assert all(v == 1.0 for v in res.values()) and ctrl == 0.0


def test_pipeline_extract_labels_then_train_tree_and_evaluate(tmp_path):
    import json
    import numpy as np
    dense_lm = os.path.join(ROOT, '..', 'external', 'dense_lm.py')
    extract = os.path.join(ROOT, '..', 'external', 'extract_needles.py')
    if not (os.path.exists(dense_lm) and os.path.exists(extract)):
        return                                                                 # the external folder lives next to the repo, not in it
    d = tmp_path / 'data'
    d.mkdir()
    rng = np.random.default_rng(0)
    for name, n in (('train', 6000), ('val', 3000)):
        arr = rng.integers(1, 64, n).astype(np.uint16)
        arr[::300] = 0
        arr.tofile(d / (name + '.bin'))
    json.dump({'vocab': 64, 'eot': 0, 'cross_docs': True}, open(d / 'meta.json', 'w'))
    arch = ['--n_layer', '2', '--n_head', '2', '--n_embd', '64']
    out = _run([dense_lm, '--repo', ROOT, '--data_dir', str(d), '--out', str(tmp_path / 'dense'), '--seq_len', '64', '--eval_lens', '64,128',
                '--val_windows', '2', '--batch', '2', '--steps', '3', '--warmup', '2'] + arch)
    assert 'FINAL validation loss' in out
    out = _run([extract, '--repo', ROOT, '--data_dir', str(d), '--dense_ckpt', str(tmp_path / 'dense' / 'ckpt.pt'), '--out', str(tmp_path / 'lab'),
                '--T', '64', '--n_windows', '40', '--rows', '8', '--thresh', '0.0', '--min_dist', '4', '--batch', '4', '--chunk', '32'] + arch)
    assert 'label distance mix' in out
    out = _run([os.path.join(ROOT, 'scripts', 'train_lm.py'), '--data_dir', str(d), '--out', str(tmp_path / 'tree'), '--labels_dir', str(tmp_path / 'lab'),
                '--seq_len', '64', '--eval_lens', '64,128', '--val_windows', '2', '--batch', '2', '--steps', '3', '--warmup', '2', '--log_every', '1',
                '--val_every', '2', '--save_every', '2', '--wmax', '16', '--beam_classes', '2,3,4,6,8', '--max_keys', '40', '--q_chunk', '64'] + arch)
    assert 'routing labels 40 windows' in out and 'FINAL validation loss' in out and 'label-hit/layer' in out
    out = _run([os.path.join(ROOT, 'scripts', 'eval_lm.py'), '--ckpt', str(tmp_path / 'tree' / 'ckpt.pt'), '--data_dir', str(d), '--eval_lens', '64',
                '--val_windows', '2', '--tree_off', '1'])
    assert 'OFF' in out
    out = _run([os.path.join(ROOT, 'scripts', 'check_decode.py'), '--ckpt', str(tmp_path / 'tree' / 'ckpt.pt'), '--data_dir', str(d), '--T', '256',
                '--n_decode', '16', '--n_gen', '8'])
    assert 'DECODE CHECK' in out


def test_prepare_wiki_from_local_text(tmp_path):
    import pytest
    pytest.importorskip('tokenizers')
    import json
    import numpy as np
    src = tmp_path / 'wiki'
    src.mkdir()
    rng = np.random.default_rng(2)
    words = ['alpha', 'beta', 'gamma', 'delta', 'omega', 'river', 'stone', 'light', 'shadow', 'winter']
    for i in range(10):
        (src / ('a%d.txt' % i)).write_text(' '.join(rng.choice(words, 400)))
    out = tmp_path / 'w'
    _run([os.path.join(ROOT, 'scripts', 'prepare_wiki.py'), '--out', str(out), '--local_txt_dir', str(src), '--val_articles', '2',
          '--tok_articles', '3', '--vocab', '300', '--train_tokens', '100'])
    meta = json.load(open(out / 'meta.json'))
    assert meta['train_tokens'] > 100 and meta['val_tokens'] > 0 and meta['cross_docs'] is True
    assert os.path.exists(out / 'tokenizer.json')


def test_needle_eval_script_on_a_tiny_model_and_tokenizer(tmp_path):
    import pytest
    pytest.importorskip('tokenizers')
    import numpy as np
    src = tmp_path / 'wiki'
    src.mkdir()
    rng = np.random.default_rng(3)
    words = ['alpha', 'beta', 'river', 'stone', 'light', 'winter', 'omega', 'delta', 'forest', 'silver']
    for i in range(10):
        (src / ('a%d.txt' % i)).write_text(' '.join(rng.choice(words, 500)))
    d = tmp_path / 'w'
    _run([os.path.join(ROOT, 'scripts', 'prepare_wiki.py'), '--out', str(d), '--local_txt_dir', str(src), '--val_articles', '3', '--tok_articles', '3',
          '--vocab', '500', '--train_tokens', '1500'])
    arch = ['--n_layer', '2', '--n_head', '2', '--n_embd', '64']
    _run([os.path.join(ROOT, 'scripts', 'train_lm.py'), '--data_dir', str(d), '--out', str(tmp_path / 'm'), '--seq_len', '64', '--eval_lens', '64',
          '--val_windows', '2', '--batch', '2', '--steps', '2', '--save_every', '2', '--wmax', '16', '--beam_classes', '2,3,4,6,8', '--max_keys', '40',
          '--q_chunk', '64'] + arch)
    out = _run([os.path.join(ROOT, 'scripts', 'needle_eval.py'), '--ckpt', str(tmp_path / 'm' / 'ckpt.pt'), '--data_dir', str(d), '--lengths', '256,512',
                '--depths', '0.2,0.8', '--n', '2', '--gen', '4', '--min_answer_id', '0', '--out', str(tmp_path / 'demo.txt')])
    assert 'NEEDLE-IN-WIKIPEDIA' in out and 'PROMPT' in out and 'expected next word' in out
    assert os.path.exists(tmp_path / 'demo.txt')
    out = _run([os.path.join(ROOT, 'scripts', 'needle_eval.py'), '--ckpt', str(tmp_path / 'm' / 'ckpt.pt'), '--data_dir', str(d), '--lengths', '256',
                '--depths', '0.5', '--n', '1', '--gen', '2', '--min_answer_id', '0', '--tree_off', '1'])
    assert 'TREE OFF' in out
