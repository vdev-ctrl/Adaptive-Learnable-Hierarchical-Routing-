# treeattn: sub-quadratic tree attention

Pure sub-quadratic code, no dense attention anywhere (benchmark against dense models externally).

## Layout
- `treeattn/tree.py`      positional binary tree (index vectors = sums), causal beam descent, neighbour search, budget split, routing loss
- `treeattn/spike.py`     spike detector on the TOKENS (before the splitter): local gradient + loose global range, graded smooth amplification
- `treeattn/attention.py` attention module: splitter (qkv), budget predictor, key selection, exact sparse attention, decode cache
- `treeattn/model.py`     standard FFN + blocks + GPT + cached `generate`
- `treeattn/tasks.py`     needle-in-a-haystack and MQAR (Zoology-style) generators; `evaluate.py` accuracy / hit-rate metrics
- `scripts/train_mqar.py` one MQAR configuration, from scratch, accuracy every N steps, final extrapolation grid
- `scripts/diagnose_mqar.py` inference-only diagnostics on a trained MQAR checkpoint (spike recall, beam drop-out level, budget histogram, ablations)
- `tests/test_core.py`    causality, tree coverage, decode == parallel, spike statistics, gradients to both trainable functions

## Spike detector (new in this version)
Decided on `x` (the layer input) before the splitter, so the key multiplier is differentiable w.r.t. embeddings and earlier layers
and the routing loss can teach the network to make important tokens spiky.
- local score: RMS z-score of x_t against the previous 64 tokens (trailing window, prefix sums, O(T))
- global gate: z-score against the running global mean/std (running sums); sigmoid gate around a loose running quantile (median)
- multiplier `1 + amp * scale * e`, `e` a smooth softplus ramp above a running quantile threshold (frozen at inference)
- `--spike_scale d` (multiplier ~ content dims) or `--spike_scale sqrt_n` (multiplier ~ sqrt of #keys before the token; `--spike_amp 3` equals the `d` version at n = 256)
- `--node_norm mean|sqrt|none` is a separate knob: how tree-node scores are divided by node size

## Design decisions
- Padding zeros go at the end (future side); a causal descent never reads them, so this equals uniform padding.
- Causal tree = left siblings along the root-to-t path ("fractal" rule); training and inference share the same code.
- The tree indexes only content dims; `rot_dims` carry rotary position and are used only by exact attention.
- Anti-dilution global vector = exclusive prefix sum of amplified index keys, fed to the budget predictor.
- Routing loss (synthetic tasks): at each query, the ancestors of its target key must outrank other past nodes at every level.

## Limits
- Selection is pure PyTorch (no Triton): per-step time at short T is dominated by launch overhead, not by FLOPs.
- The test-suite and scripts were written without GPU access in the authoring environment: run `python -m pytest tests -q` first.
