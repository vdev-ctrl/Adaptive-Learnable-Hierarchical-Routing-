"""PHASE 2: train the tree model (splitter + budget predictor + the common FFN) against the dense reference.

  * the dense phase-1 checkpoint is loaded twice: as the FROZEN reference (its attention rows are extracted every step) and as the
    initialisation of the tree model (embedding, norms and FFN are the same weights; with --copy_attn 1 the dense qkv / proj also
    warm-start the tree's splitter / output projection);
  * loss = next-token loss (refines the common FFN, and everything else)
         + split_weight * splitter loss   (tree-node scores must follow the dense attention mass per node, every level)
         + pred_weight  * budget loss     (leaf groups needed to hold ref_mass of the dense attention, as a class)
  * the shared parameters (embedding, norms, FFN) train at lr * shared_lr_mult: their main training happened in phase 1.
Dense attention is used here only to produce the reference. Inference (eval_lm / check_decode / generate) never touches it.
  python scripts/train_tree.py --data_dir data/wiki --dense_ckpt runs/dense/ckpt.pt --out runs/tree --steps 2000"""
import argparse
import json
import math
import os
import sys
import time

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from treeattn import Config, GPT
from treeattn.distill import sample_rows
from treeattn.lmdata import bucket_line, train_batch, val_windows, window

p = argparse.ArgumentParser()
p.add_argument('--data_dir', default='data/wiki')
p.add_argument('--dense_ckpt', required=True)
p.add_argument('--out', default='runs/tree')
p.add_argument('--seed', type=int, default=1)
p.add_argument('--eval_lens', default='1024,4096,16384')
p.add_argument('--val_windows', type=int, default=24)
p.add_argument('--batch', type=int, default=16)
p.add_argument('--steps', type=int, default=2000)
p.add_argument('--lr', type=float, default=3e-4)
p.add_argument('--shared_lr_mult', type=float, default=0.1, help='lr multiplier of the shared parts (embedding, norms, FFN)')
p.add_argument('--warmup', type=int, default=100)
p.add_argument('--copy_attn', type=int, default=1, help='1: warm-start splitter / projection from the dense head')
p.add_argument('--split_weight', type=float, default=0.3)
p.add_argument('--pred_weight', type=float, default=0.1)
p.add_argument('--ref_rows', type=int, default=128)
p.add_argument('--ref_mass', type=float, default=0.9)
p.add_argument('--wmax', type=int, default=32, help='beam width = most leaf groups (2 keys each) the tree can add per query')
p.add_argument('--beam_classes', default='2,4,8,16,32', help='budget classes in leaf groups; the largest must be <= wmax')
p.add_argument('--max_keys', type=int, default=96, help='hard cap on keys read per query (a constant)')
p.add_argument('--q_chunk', type=int, default=256)
p.add_argument('--rope_cap', type=int, default=-1, help='-1 = seq_len (exact attention never sees a distance beyond the training window), 0 = off')
p.add_argument('--log_every', type=int, default=50)
p.add_argument('--val_every', type=int, default=500)
p.add_argument('--save_every', type=int, default=250)
a = p.parse_args()

dev = 'cuda' if torch.cuda.is_available() else 'cpu'
dck = torch.load(a.dense_ckpt, map_location=dev, weights_only=False)
dcfg = Config(**dck['cfg'])
meta = json.load(open(os.path.join(a.data_dir, 'meta.json')))
cfg = Config(**{**dcfg.to_dict(), 'wmax': a.wmax, 'beam_classes': tuple(int(v) for v in a.beam_classes.split(',')), 'max_keys': a.max_keys,
                'q_chunk': a.q_chunk, 'ref_rows': a.ref_rows, 'ref_mass': a.ref_mass, 'split_weight': a.split_weight,
                'pred_weight': a.pred_weight, 'rope_cap': dcfg.seq_len if a.rope_cap < 0 else a.rope_cap})
torch.manual_seed(a.seed)

teacher = GPT(dcfg, 'dense').to(dev)                                  # frozen reference: the phase-1 model, never updated
teacher.load_state_dict(dck['model'])
teacher.eval()
for q_ in teacher.parameters():
    q_.requires_grad_(False)

model = GPT(cfg, 'tree').to(dev)
fresh = model.load_dense(dck['model'], copy_attn=bool(a.copy_attn))   # shared FFN etc. come from phase 1
print('PHASE 2 tree | device %s | params %.2fM | seq_len %d | batch %d | steps %d | warm-start splitter %s | fresh params: %d tensors '
      '(budget predictor%s) | wmax %d classes %s max_keys %d rope_cap %d' % (
          dev, sum(q.numel() for q in model.parameters()) / 1e6, cfg.seq_len, a.batch, a.steps, bool(a.copy_attn), len(fresh),
          '' if a.copy_attn else ' + splitter + proj', cfg.wmax, a.beam_classes, cfg.max_keys, cfg.rope_cap), flush=True)

shared = [q_ for n_, q_ in model.named_parameters() if '.attn.' not in n_]
attn = [q_ for n_, q_ in model.named_parameters() if '.attn.' in n_]
groups = [{'params': shared, 'mult': a.shared_lr_mult}, {'params': attn, 'mult': 1.0}]
opt = torch.optim.AdamW(groups, lr=a.lr, betas=(0.9, 0.95), weight_decay=0.1)
tr = np.memmap(os.path.join(a.data_dir, 'train.bin'), dtype=np.uint16, mode='r')
va = np.memmap(os.path.join(a.data_dir, 'val.bin'), dtype=np.uint16, mode='r')
cross = bool(meta.get('cross_docs', False))
use_amp = dev == 'cuda'
scaler = torch.amp.GradScaler('cuda', enabled=use_amp)
os.makedirs(a.out, exist_ok=True)
ckpt_path = os.path.join(a.out, 'ckpt.pt')
step = 0
if os.path.exists(ckpt_path):
    ck = torch.load(ckpt_path, map_location=dev, weights_only=False)
    model.load_state_dict(ck['model'])
    opt.load_state_dict(ck['opt'])
    step = ck['step']
    print('resumed at step', step, flush=True)


def save():
    torch.save({'cfg': cfg.to_dict(), 'attn': 'tree', 'model': model.state_dict(), 'opt': opt.state_dict(), 'step': step, 'meta': meta}, ckpt_path)


@torch.no_grad()
def evaluate(T, n, with_ref=False):
    """loss/acc by position; with_ref also returns the share of the dense attention mass the tree read (windows of length T)."""
    model.eval()
    starts = val_windows(va, meta['eot'], T, n, cross=cross)
    tot = hit = None
    mass = []
    for s in starts:
        x, y = window(va, s, T, dev)
        ref = None
        with torch.autocast(dev, dtype=torch.float16, enabled=use_amp):
            if with_ref:
                rows = sample_rows(1, T, min(cfg.ref_rows, T - cfg.ref_min_pos), cfg.ref_min_pos, s, 0, dev)
                ref = (rows, teacher.extract_reference(x, rows))
            lg, _, st = model(x, ref=ref)
        if with_ref:
            mass.append(st['mass'])
        ce = torch.nn.functional.cross_entropy(lg.float().view(-1, lg.size(-1)), y.view(-1), reduction='none')
        ok = (lg.argmax(-1).view(-1) == y.view(-1)).float()
        tot, hit = (ce, ok) if tot is None else (tot + ce, hit + ok)
    model.train()
    return tot / max(len(starts), 1), hit / max(len(starts), 1), len(starts), (float(np.mean(mass)) if mass else None)


t_start, n_done, ema, bad = time.time(), 0, None, 0
model.train()
while step < a.steps:
    lr = a.lr * min(1.0, (step + 1) / a.warmup) * (0.1 + 0.9 * 0.5 * (1 + math.cos(math.pi * step / a.steps)))
    for g in opt.param_groups:
        g['lr'] = lr * g['mult']
    x, y = train_batch(tr, a.batch, cfg.seq_len, step, a.seed, dev)
    rows = sample_rows(a.batch, cfg.seq_len, cfg.ref_rows, cfg.ref_min_pos, step, a.seed, dev)
    with torch.autocast(dev, dtype=torch.float16, enabled=use_amp):
        ref = (rows, teacher.extract_reference(x, rows))              # the dense attention rows, frozen teacher
        _, loss, st = model(x, y, ref=ref)
    if not torch.isfinite(loss):
        bad += 1
        print('non-finite loss at step', step, '- skipped (%d in a row)' % bad, flush=True)
        if bad >= 20:
            raise SystemExit('training diverged: 20 non-finite steps in a row')
        step += 1
        continue
    bad = 0
    opt.zero_grad(set_to_none=True)
    scaler.scale(loss).backward()
    scaler.unscale_(opt)
    torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
    scaler.step(opt)
    scaler.update()
    step += 1
    n_done += 1
    ema = st['lm'] if ema is None else 0.98 * ema + 0.02 * st['lm']
    if step % a.log_every == 0 or step == 1:
        print('step %d | lm %.3f (ema %.3f) split %.3f pred %.3f | dense-mass read %.3f | keys %.1f | lr %.1e | %.2fs/step' % (
            step, st['lm'], ema, st['split'], st['pred'], st.get('mass', 0), st.get('keys', 0), lr, (time.time() - t_start) / n_done), flush=True)
        if 'chist' in st and (step % (a.log_every * 4) == 0 or step == 1):
            print('    budget classes %s, share of queries per class per layer: %s' % (a.beam_classes, ' '.join(
                '[' + ','.join('%.2f' % v for v in h) + ']' for h in st['chist'])), flush=True)
    if step % a.val_every == 0:
        ce, ac, n, ms = evaluate(cfg.seq_len, 16, with_ref=True)
        print('  VAL step %d | T=%d | loss %.3f acc %.3f | dense attention mass read %.3f (%d windows)' % (
            step, cfg.seq_len, ce.mean().item(), ac.mean().item(), ms, n), flush=True)
    if step % a.save_every == 0 or step == a.steps:
        save()

print('\n=== FINAL validation (tree, inference path only) | loss/acc by position bucket. Trained at %d.' % cfg.seq_len)
for T in [int(v) for v in a.eval_lens.split(',')]:
    ce, ac, n, _ = evaluate(T, a.val_windows)
    print('T=%-6d (%d windows) %s' % (T, n, bucket_line(ce, ac, T, cfg.seq_len)), flush=True)
