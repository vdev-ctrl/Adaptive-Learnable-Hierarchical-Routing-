"""PHASE 1: regular training of the dense head + FFN (full causal softmax attention, next-token loss). This is where the FFN
(and the embeddings / norms) get their main training. The checkpoint is the starting point and the frozen reference of phase 2.
  python scripts/train_dense.py --data_dir data/wiki --out runs/dense --steps 3000 --n_layer 8 --n_head 6 --n_embd 384"""
import argparse
import json
import math
import os
import sys
import time

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from treeattn import Config, GPT
from treeattn.lmdata import bucket_line, train_batch, val_windows, window

p = argparse.ArgumentParser()
p.add_argument('--data_dir', default='data/wiki')
p.add_argument('--out', default='runs/dense')
p.add_argument('--seed', type=int, default=0)
p.add_argument('--seq_len', type=int, default=1024)
p.add_argument('--eval_lens', default='1024,2048,4096')
p.add_argument('--val_windows', type=int, default=24)
p.add_argument('--batch', type=int, default=16)
p.add_argument('--steps', type=int, default=3000)
p.add_argument('--lr', type=float, default=1e-3)
p.add_argument('--warmup', type=int, default=100)
p.add_argument('--n_layer', type=int, default=8)
p.add_argument('--n_head', type=int, default=6)
p.add_argument('--n_embd', type=int, default=384)
p.add_argument('--log_every', type=int, default=50)
p.add_argument('--val_every', type=int, default=500)
p.add_argument('--save_every', type=int, default=250)
a = p.parse_args()

dev = 'cuda' if torch.cuda.is_available() else 'cpu'
meta = json.load(open(os.path.join(a.data_dir, 'meta.json')))
cfg = Config(vocab_size=meta['vocab'], seq_len=a.seq_len, n_layer=a.n_layer, n_head=a.n_head, n_embd=a.n_embd)
torch.manual_seed(a.seed)
model = GPT(cfg, 'dense').to(dev)
print('PHASE 1 dense | device %s | params %.2fM | seq_len %d | batch %d | steps %d' % (
    dev, sum(q.numel() for q in model.parameters()) / 1e6, a.seq_len, a.batch, a.steps), flush=True)
tr = np.memmap(os.path.join(a.data_dir, 'train.bin'), dtype=np.uint16, mode='r')
va = np.memmap(os.path.join(a.data_dir, 'val.bin'), dtype=np.uint16, mode='r')
cross = bool(meta.get('cross_docs', False))
opt = torch.optim.AdamW(model.parameters(), lr=a.lr, betas=(0.9, 0.95), weight_decay=0.1)
use_amp = dev == 'cuda'
scaler = torch.amp.GradScaler('cuda', enabled=use_amp)
os.makedirs(a.out, exist_ok=True)
ckpt_path = os.path.join(a.out, 'ckpt.pt')
step = 0
if os.path.exists(ckpt_path):
    ck = torch.load(ckpt_path, map_location=dev, weights_only=False)
    model.load_state_dict(ck['model'])
    opt.load_state_dict(ck['opt'])
    step = ck['step']
    print('resumed at step', step, flush=True)


def save():
    torch.save({'cfg': cfg.to_dict(), 'attn': 'dense', 'model': model.state_dict(), 'opt': opt.state_dict(), 'step': step, 'meta': meta}, ckpt_path)


@torch.no_grad()
def evaluate(T, n):
    model.eval()
    starts = val_windows(va, meta['eot'], T, n, cross=cross)
    tot = hit = None
    for s in starts:
        x, y = window(va, s, T, dev)
        with torch.autocast(dev, dtype=torch.float16, enabled=use_amp):
            lg, _, _ = model(x)
        ce = torch.nn.functional.cross_entropy(lg.float().view(-1, lg.size(-1)), y.view(-1), reduction='none')
        ok = (lg.argmax(-1).view(-1) == y.view(-1)).float()
        tot, hit = (ce, ok) if tot is None else (tot + ce, hit + ok)
    model.train()
    return tot / max(len(starts), 1), hit / max(len(starts), 1), len(starts)


t_start, n_done, ema = time.time(), 0, None
model.train()
while step < a.steps:
    lr = a.lr * min(1.0, (step + 1) / a.warmup) * (0.1 + 0.9 * 0.5 * (1 + math.cos(math.pi * step / a.steps)))
    for g in opt.param_groups:
        g['lr'] = lr
    x, y = train_batch(tr, a.batch, a.seq_len, step, a.seed, dev)
    with torch.autocast(dev, dtype=torch.float16, enabled=use_amp):
        _, loss, st = model(x, y)
    opt.zero_grad(set_to_none=True)
    scaler.scale(loss).backward()
    scaler.unscale_(opt)
    torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
    scaler.step(opt)
    scaler.update()
    step += 1
    n_done += 1
    ema = st['lm'] if ema is None else 0.98 * ema + 0.02 * st['lm']
    if step % a.log_every == 0 or step == 1:
        print('step %d | lm %.3f (ema %.3f) | lr %.1e | %.2fs/step' % (step, st['lm'], ema, lr, (time.time() - t_start) / n_done), flush=True)
    if step % a.val_every == 0:
        ce, ac, n = evaluate(a.seq_len, 16)
        print('  VAL step %d | T=%d | loss %.3f acc %.3f (%d windows)' % (step, a.seq_len, ce.mean().item(), ac.mean().item(), n), flush=True)
    if step % a.save_every == 0 or step == a.steps:
        save()

print('\n=== FINAL validation (dense) | loss/acc by position bucket. Trained at %d.' % a.seq_len)
for T in [int(v) for v in a.eval_lens.split(',')]:
    try:
        ce, ac, n = evaluate(T, a.val_windows)
        print('T=%-6d (%d windows) %s' % (T, n, bucket_line(ce, ac, T, a.seq_len)), flush=True)
    except torch.cuda.OutOfMemoryError:
        print('T=%-6d out of memory (dense attention)' % T, flush=True)
        torch.cuda.empty_cache()
